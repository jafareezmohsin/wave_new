<div class="wv-frame__content__header" bis_skin_checked="1">
                        <div class="wv-topbar--app zebo" bis_skin_checked="1">
                            <div class="wv-topbar__menu-toggle" bis_skin_checked="1"><span
                                    class="wv-topbar__menu-toggle__icon"><span></span><span></span><span></span><span></span></span><span
                                    class="wv-topbar__menu-toggle__label fs-unmask">Menu</span></div><span
                                class="wv-topbar__business-name">Derman</span><a class="wv-nav__promo--topbar fs-unmask"
                                href="https://next.waveapps.com/4ca14d42-ebb1-425c-8837-93261d4e42c6/payments?source=nav/top&amp;referer=app"><i
                                    class="wv-nav__promo__icon--small"><svg xmlns="http://www.w3.org/2000/svg"
                                        xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="16"
                                        viewBox="0 0 47 32">
                                        <path
                                            d="M47 6H0V5a5 5 0 0 1 5-5h37a5 5 0 0 1 5 5v1zm0 6v15a5 5 0 0 1-5 5H5a5 5 0 0 1-5-5V12h47zM5 15v4h16v-4H5z">
                                        </path>
                                    </svg></i>
                                <p class="wv-nav__promo__title">Accept payments</p>
                            </a>
                        </div>
                    </div>

                    <script>

        
         
jQuery(document).ready(function($) {
    $('.zebo').on('click',function(){
    console.log("asd")
      if($('.pg-launchpad').hasClass('is-open')){
        $('.pg-launchpad').removeClass('is-open');
        console.log("as")
      }else{
        $('.pg-launchpad').addClass('is-open');
      }
   });
});  
    </script>