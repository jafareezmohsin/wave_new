<style>
    .wv-frame__navigation.is-active {
    background: #348d7024 !important;
}
.wv-business-switcher__toggle {
    background: #1AC18C !important;
}
.wv-nav__menu__item__icon { 
    color: #348d7024 !important;
}
.wv-nav__menu--apps .wv-nav__menu__item.is-current .wv-nav__menu__item__label {
 
    color: #00d08a !important;
}
</style>

<div class="wv-frame__navigation is-active" bis_skin_checked="1">
                    <div class="wv-business-switcher" bis_skin_checked="1">
                        <div class="wv-business-switcher__toggle" bis_skin_checked="1">
                            <div class="wv-business-switcher__toggle__logo" bis_skin_checked="1"><span
                                    class="wv-logo--mark fs-unmask">Wave</span></div>
                            <div class="wv-business-switcher__toggle__info" bis_skin_checked="1">
                                <div class="wv-business-switcher__toggle__info__business" bis_skin_checked="1">Derman
                                </div>
                            </div><svg class="wv-svg-icon wv-business-switcher__toggle__caret"
                                aria-labelledby="expand-title" aria-hidden="false">
                                <title id="expand-title">expand icon</title>
                                <use xlink:href="#expand"></use>
                            </svg>
                        </div>
                        <div class="wv-business-switcher__panel" bis_skin_checked="1">
                            <div class="wv-business-switcher__panel__header" bis_skin_checked="1">
                                <div class="wv-business-switcher__toggle__logo" bis_skin_checked="1"><span
                                        class="wv-logo--mark">Wave</span></div>
                                <div class="wv-business-switcher__panel__header__title fs-unmask" bis_skin_checked="1">
                                    Your Wave account</div>
                                <div class="wv-business-switcher__panel__header__close wv-close--large"
                                    bis_skin_checked="1"></div>
                            </div>
                            <div class="wv-business-switcher__panel__body" bis_skin_checked="1">
                                <div class="wv-business-switcher__panel__body__section" bis_skin_checked="1">
                                    <ul class="wv-business-switcher__business-menu">
                                        <li class="wv-business-switcher__business-menu__item is-current"><a
                                                class="wv-business-switcher__business-menu__item__link fs-exclude"
                                                href="https://my.waveapps.com/4ca14d42-ebb1-425c-8837-93261d4e42c6/business-switcher-redirect/"><span
                                                    class="wv-business-switcher__business-menu__item__label">Derman</span><svg
                                                    class="wv-svg-icon" aria-labelledby="check-title"
                                                    aria-hidden="false">
                                                    <title id="check-title">check icon</title>
                                                    <use xlink:href="#check"></use>
                                                </svg></a></li>
                                        <li class="wv-business-switcher__business-menu__item"><a
                                                class="wv-business-switcher__business-menu__item__link fs-exclude"
                                                href="https://my.waveapps.com/775a75cd-6f0d-458f-9e88-a2210c7246f1/business-switcher-redirect/"><span
                                                    class="wv-business-switcher__business-menu__item__label">Personal</span></a>
                                        </li>
                                    </ul>
                                    <div class="wv-business-switcher__business-menu__add fs-unmask"
                                        bis_skin_checked="1"><svg
                                            class="wv-svg-icon--large wv-business-switcher__context-menu__item__icon"
                                            aria-labelledby="add--large-title" aria-hidden="false">
                                            <title id="add--large-title">add large icon</title>
                                            <use xlink:href="#add--large"></use>
                                        </svg><a class="wv-text wv-text--small wv-text--link"
                                            href="https://api.waveapps.com/go/create_business/4ca14d42-ebb1-425c-8837-93261d4e42c6/">Create
                                            a new business</a></div>
                                </div>
                                <div class="wv-business-switcher__panel__body__section" bis_skin_checked="1">
                                    <div class="wv-text wv-text--small fs-unmask" bis_skin_checked="1">You're signed in
                                        as <strong
                                            class="wv-business-switcher__user-email fs-exclude">dermanedina@gmail.com</strong>.
                                    </div>
                                    <ul class="wv-business-switcher__context-menu fs-unmask">
                                        <li class="wv-business-switcher__context-menu__item"><svg
                                                class="wv-svg-icon--large wv-business-switcher__context-menu__item__icon"
                                                aria-labelledby="profile--large-title" aria-hidden="false">
                                                <title id="profile--large-title">profile large icon</title>
                                                <use xlink:href="#profile--large"></use>
                                            </svg><a class="wv-business-switcher__context-menu__item__link"
                                                href="https://api.waveapps.com/go/profile/4ca14d42-ebb1-425c-8837-93261d4e42c6/"><span
                                                    class="wv-business-switcher__context-menu__item__label">Manage your
                                                    profile</span></a></li>
                                        <li class="wv-business-switcher__context-menu__item"><svg
                                                class="wv-svg-icon--large wv-business-switcher__context-menu__item__icon"
                                                aria-labelledby="logout--large-title" aria-hidden="false">
                                                <title id="logout--large-title">logout large icon</title>
                                                <use xlink:href="#logout--large"></use>
                                            </svg><a class="wv-business-switcher__context-menu__item__link"
                                                href="https://api.waveapps.com/go/logout/"><span
                                                    class="wv-business-switcher__context-menu__item__label">Sign
                                                    out</span></a></li>
                                    </ul>
                                </div>
                                <div class="wv-business-switcher__panel__body__section" bis_skin_checked="1">
                                    <p class="wv-text wv-text--body fs-unmask fs-exclude"><a
                                            class="wv-business-switcher__legal__link" target="_blank"
                                            href="https://www.waveapps.com/legal/terms-of-use"
                                            rel="noopener noreferrer">Terms</a><span
                                            class="wv-business-switcher__legal__separator">•</span><a
                                            class="wv-business-switcher__legal__link" target="_blank"
                                            href="https://www.waveapps.com/legal/privacy-policy"
                                            rel="noopener noreferrer">Privacy</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <nav class="wv-nav wv-nav--primary has-payments-promo" role="navigation">
                        <ul class="wv-nav__menu wv-nav__menu--apps">
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="launchpad.php"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#launchpad"></use>
                                    </svg><span class="wv-nav__menu__item__label">Launchpad</span></a></li>
                            <li class="wv-nav__menu__item is-current is-open"><a
                                    class="wv-nav__menu__item__link fs-unmask"
                                    href="dashboard.php"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#meter"></use>
                                    </svg><span class="wv-nav__menu__item__label">Dashboard</span></a></li>
                            <li class="wv-nav__menu__item wv-nav__menu__item--expandable febss">
                                <div class="wv-nav__menu__item__link fs-unmask" bis_skin_checked="1"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#creditcard"></use>
                                    </svg><span class="wv-nav__menu__item__label">Sales &amp; Payments</span><svg
                                        class="wv-svg-icon wv-nav__menu__item__caret" aria-labelledby="expand-title"
                                        aria-hidden="false">
                                        <title id="expand-title">expand icon</title>
                                        <use xlink:href="#expand"></use>
                                    </svg></div>
                                <div class="wv-nav__menu__item__expandable-content" bis_skin_checked="1">
                                    <ul class="wv-nav__menu wv-nav__menu--nested">
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://accounting.waveapps.com/invoices/4ca14d42-ebb1-425c-8837-93261d4e42c6/estimates/redirect?referer=app">Estimates</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/invoice/4ca14d42-ebb1-425c-8837-93261d4e42c6?referer=app">Invoices</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payments_tab/4ca14d42-ebb1-425c-8837-93261d4e42c6?referer=app">Payments
                                                Setup</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/recurring-invoices?referer=app">Recurring
                                                Invoices</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/checkouts?referer=app">Checkouts<span
                                                    class="wv-nav__menu__item__link__beta-badge">beta</span></a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/customer-statements?referer=app">Customer
                                                Statements</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="customer.php">Customers</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://accounting.waveapps.com/products/4ca14d42-ebb1-425c-8837-93261d4e42c6/selling/redirect?referer=app">Products
                                                &amp; Services</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="wv-nav__menu__item wv-nav__menu__item--expandable febss">
                                <div class="wv-nav__menu__item__link fs-unmask" bis_skin_checked="1"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#receipt"></use>
                                    </svg><span class="wv-nav__menu__item__label">Customer</span><svg
                                        class="wv-svg-icon wv-nav__menu__item__caret" aria-labelledby="expand-title"
                                        aria-hidden="false">
                                        <title id="expand-title">expand icon</title>
                                        <use xlink:href="#expand"></use>
                                    </svg></div>
                                <div class="wv-nav__menu__item__expandable-content" bis_skin_checked="1">
                                    <ul class="wv-nav__menu wv-nav__menu--nested">
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/bills?referer=app">Bills</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://accounting.waveapps.com/settings/4ca14d42-ebb1-425c-8837-93261d4e42c6/vendors/redirect?referer=app">Vendors</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://accounting.waveapps.com/products/4ca14d42-ebb1-425c-8837-93261d4e42c6/buying/redirect?referer=app">Products
                                                &amp; Services</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="wv-nav__menu__item wv-nav__menu__item--expandable febss">
                                <div class="wv-nav__menu__item__link fs-unmask" bis_skin_checked="1"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#balance"></use>
                                    </svg><span class="wv-nav__menu__item__label">Accounting</span><svg
                                        class="wv-svg-icon wv-nav__menu__item__caret" aria-labelledby="expand-title"
                                        aria-hidden="false">
                                        <title id="expand-title">expand icon</title>
                                        <use xlink:href="#expand"></use>
                                    </svg></div>
                                <div class="wv-nav__menu__item__expandable-content" bis_skin_checked="1">
                                    <ul class="wv-nav__menu wv-nav__menu--nested">
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/transactions?referer=app">Transactions</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/account-reconciliation/accounts?referer=app">Reconciliation</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/accounting/charts?referer=app">Chart
                                                of Accounts</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/proservices?referer=app">Hire
                                                a Bookkeeper</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="wv-nav__menu__item wv-nav__menu__item--expandable febss">
                                <div class="wv-nav__menu__item__link fs-unmask" bis_skin_checked="1"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#bank"></use>
                                    </svg><span class="wv-nav__menu__item__label">Banking</span><svg
                                        class="wv-svg-icon wv-nav__menu__item__caret" aria-labelledby="expand-title"
                                        aria-hidden="false">
                                        <title id="expand-title">expand icon</title>
                                        <use xlink:href="#expand"></use>
                                    </svg></div>
                                <div class="wv-nav__menu__item__expandable-content" bis_skin_checked="1">
                                    <ul class="wv-nav__menu wv-nav__menu--nested">
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/connected-accounts?referer=app">Connected
                                                Accounts</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/payments/transfers?referer=app">Payouts</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/next-insurance?referer=app">Insurance</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="wv-nav__menu__item wv-nav__menu__item--expandable febss">
                                <div class="wv-nav__menu__item__link fs-unmask" bis_skin_checked="1"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#badge"></use>
                                    </svg><span class="wv-nav__menu__item__label">Payroll</span><svg
                                        class="wv-svg-icon wv-nav__menu__item__caret" aria-labelledby="expand-title"
                                        aria-hidden="false">
                                        <title id="expand-title">expand icon</title>
                                        <use xlink:href="#expand"></use>
                                    </svg><span class="wv-nav__menu__item__link__trial-badge is-primary">trial</span>
                                </div>
                                <div class="wv-nav__menu__item__expandable-content" bis_skin_checked="1">
                                    <ul class="wv-nav__menu wv-nav__menu--nested">
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Frun&amp;referer=app">Run
                                                Payroll</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_employees/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Femployees&amp;referer=app">Employees</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_timesheets/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Ftimesheets&amp;referer=app">Timesheets</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_transactions/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Ftransactions&amp;referer=app">Payroll
                                                Transactions</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_taxes/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Ftaxes&amp;referer=app">Taxes</a>
                                        </li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_tax_forms/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Ftaxforms&amp;referer=app">Tax
                                                Forms</a></li>
                                        <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                                href="https://api.waveapps.com/go/qs/payroll_covid19/4ca14d42-ebb1-425c-8837-93261d4e42c6/?source=nav%2Fpayroll%2Fcovid19&amp;referer=app">COVID-19</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="https://api.waveapps.com/go/reports/4ca14d42-ebb1-425c-8837-93261d4e42c6/"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#pie-chart"></use>
                                    </svg><span class="wv-nav__menu__item__label">Reports</span></a></li>
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="https://api.waveapps.com/go/qs/proservices/4ca14d42-ebb1-425c-8837-93261d4e42c6/?origin=primary-nav&amp;source=nav%2Fadvisors"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#users"></use>
                                    </svg><span class="wv-nav__menu__item__label">Wave Advisors</span></a></li>
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="https://api.waveapps.com/go/taxes/4ca14d42-ebb1-425c-8837-93261d4e42c6/"><svg
                                        class="wv-svg-icon wv-nav__menu__item__icon">
                                        <use xlink:href="#taxes "></use>
                                    </svg><span class="wv-nav__menu__item__label">Tax Filing</span></a></li>
                        </ul>
                        <hr class="wv-nav__divider">
                        <ul class="wv-nav__menu wv-nav__menu--extras fs-unmask">
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="https://accounting.waveapps.com/apps/integrations/4ca14d42-ebb1-425c-8837-93261d4e42c6"><span
                                        class="wv-nav__menu__item__label">Integrations</span></a></li>
                            <li class="wv-nav__menu__item"><a class="wv-nav__menu__item__link fs-unmask"
                                    href="/4ca14d42-ebb1-425c-8837-93261d4e42c6/settings/user-management"><span
                                        class="wv-nav__menu__item__label">Settings</span></a></li>
                        </ul><a class="wv-nav__promo fs-unmask"
                            href="https://next.waveapps.com/4ca14d42-ebb1-425c-8837-93261d4e42c6/payments?source=nav/left&amp;referer=app"><i
                                class="wv-nav__promo__icon--large"><svg xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="47" height="32"
                                    viewBox="0 0 47 32">
                                    <path
                                        d="M47 6H0V5a5 5 0 0 1 5-5h37a5 5 0 0 1 5 5v1zm0 6v15a5 5 0 0 1-5 5H5a5 5 0 0 1-5-5V12h47zM5 15v4h16v-4H5z">
                                    </path>
                                </svg></i><i class="wv-nav__promo__icon--small"><svg xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="16"
                                    viewBox="0 0 47 32">
                                    <path
                                        d="M47 6H0V5a5 5 0 0 1 5-5h37a5 5 0 0 1 5 5v1zm0 6v15a5 5 0 0 1-5 5H5a5 5 0 0 1-5-5V12h47zM5 15v4h16v-4H5z">
                                    </path>
                                </svg></i>
                            <p class="wv-nav__promo__title--long">Accept credit cards &amp; bank&nbsp;payments</p>
                            <p class="wv-nav__promo__title--short">Accept payments</p>
                            <p class="wv-nav__promo__body">Get paid instantly by enabling online payments.</p>
                            <div class="wv-nav__promo__button" bis_skin_checked="1">Set up now</div>
                        </a>
                    </nav>
                </div>

                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script>

        
         
jQuery(document).ready(function($) {
    var dropdown = document.getElementsByClassName("febss");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("is-open");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "is-open") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "is-open";
    }
  });
}


$('.zebo').on('click',function(){
      if($('.pg-dashboard').hasClass('is-open')){
        $('.pg-dashboard').removeClass('is-open');
      }else{
        $('.pg-dashboard').addClass('is-open');
      }
   });
}); 
    (function() {
        window._pxAppId = 'PXYVdw1w56';
        var p = document.getElementsByTagName('script')[0],
            s = document.createElement('script');
        s.async = 1;
        s.src = '/YVdw1w56/init.js';
        p.parentNode.insertBefore(s, p);
    }());
    </script>