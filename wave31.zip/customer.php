<html lang="en" data-sentry-release-id="df756015e4" data-country="PK">

<link rel="apple-touch-icon" sizes="180x180"
    href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/apple-touch-icon.png">
<link rel="icon" type="image/png" href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/favicon-32x32.png"
    sizes="32x32">
<link rel="icon" type="image/png" href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/favicon-16x16.png"
    sizes="16x16">
<link rel="manifest" href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/site.webmanifest">
<link rel="mask-icon" href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/safari-pinned-tab.svg" color="#308df8">
<link rel="shortcut icon" href="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/favicon.ico">
<meta name="theme-color" content="#ffffff">
<meta name="msapplication-square150x150logo"
    content="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/mstile-150x150.png">
<meta name="msapplication-square310x310logo"
    content="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/mstile-310x310.png">
<meta name="msapplication-square70x70logo"
    content="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/mstile-70x70.png">
<meta name="msapplication-wide310x150logo"
    content="https://dmrokfxvkn5v8.cloudfront.net/public/wavicon/mstile-310x150.png">
<meta name="msapplication-TileColor" content="#2d89ef">
<link rel="chrome-webstore-item" href="https://chrome.google.com/webstore/detail/knpkfcpnjfbniadmfchjpcigfhookhaa">
<style>
body,
html {
    background: #fff;
    margin: 0;
    padding: 0
}

#app-shell {
    height: 100%;
    min-height: 350px;
    display: flex
}

#app-shell__sidebar {
    position: relative;
    width: 240px;
    background: #f8faff
}

#app-shell__sidebar__header__switcher {
    background: #e8effd;
    position: absolute;
    top: 0;
    left: 0;
    width: 224px;
    height: 56px;
    border-radius: 500px;
    margin: 8px
}

#app-shell__sidebar__header {
    position: absolute;
    top: 0;
    left: 0;
    animation-name: skeletonShimmer;
    animation-delay: 1.4s;
    animation-duration: 1.4s;
    animation-timing-function: ease-in-out;
    animation-iteration-count: infinite;
    animation-direction: normal
}

#app-shell__sidebar__header__svg {
    position: relative;
    z-index: 1;
    top: 22px;
    left: 15px
}

#app-shell__body {
    flex-grow: 1;
    align-self: center;
    text-align: center
}

@media (max-width:1234px) {
    #app-shell__sidebar {
        display: none
    }
}

@media screen and (min-height:550px) {
    iframe#ada-chat-frame {
        max-height: 90%
    }
}

.is-current .wv-workflow__task__action, .wv-button--with-actions--primary .wv-button, .wv-button--submit, .wv-button--primary {
    
    background-color: #1AC18C !important;
    
}
.wv-pagination__control, .is-complete .wv-workflow__task__action, .wv-button--with-actions .wv-button, .wv-button--with-actions--secondary .wv-button, .wv-button--secondary, .wv-button--secondary--danger, .wv-button, .wv-button--facebook, .wv-button--yahoo, .wv-button--google {
    color: #1AC18C !important; 
    border: 1px solid #1AC18C !important;
}

span.wv-counter.fuKT0a3nd19f45riV8fK {
    background: #348d7024;
}
.wv-table__body .wv-table__row:hover, .wv-table__rowgroup .wv-table__row:hover {
    background-color: #e0f0eb !important;
}


</style>
<link rel="stylesheet" href="https://dmrokfxvkn5v8.cloudfront.net/branches/main/buoyant-app.css">

<link href="https://next.waveapps.com/styles.4c15fcc35eba70217001.css" rel="stylesheet">
<meta http-equiv="origin-trial"
    content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
<meta http-equiv="origin-trial"
    content="A+xK4jmZTgh1KBVry/UZKUE3h6Dr9HPPioFS4KNCzify+KEoOii7z/goKS2zgbAOwhpZ1GZllpdz7XviivJM9gcAAACFeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiQXR0cmlidXRpb25SZXBvcnRpbmdDcm9zc0FwcFdlYiIsImV4cGlyeSI6MTcwNzI2Mzk5OSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==">
<meta http-equiv="origin-trial"
    content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
<link rel="stylesheet" id="1e2632c356aec017951edad899b09253"
    href="https://d1lchsxkq6tidf.cloudfront.net/2.2.0/assets/style.css">

<meta http-equiv="origin-trial"
    content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
<meta http-equiv="origin-trial"
    content="A+xK4jmZTgh1KBVry/UZKUE3h6Dr9HPPioFS4KNCzify+KEoOii7z/goKS2zgbAOwhpZ1GZllpdz7XviivJM9gcAAACFeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiQXR0cmlidXRpb25SZXBvcnRpbmdDcm9zc0FwcFdlYiIsImV4cGlyeSI6MTcwNzI2Mzk5OSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==">
<meta http-equiv="origin-trial"
    content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
<link rel="stylesheet" type="text/css" integrity="sha256-1ksk1w6tvNv0tSIxcv6kU+GFMdikj2NXJ9l+RWWflt4="
    crossorigin="anonymous"
    href="https://fast.appcues.com/generic/main/4.54.4/container.0011396862aef71d6aa8a1c8d8ee83f89f40a910.css">

<style type="text/css" id="qual_style-zba"></style>
<style type="text/css" id="qual_style-zc8"></style>
<style type="text/css" id="qual_style-zba"></style>
<style type="text/css" id="qual_style-zc8"></style>
<style data-styled="active" data-styled-version="5.3.10"></style>
</head>

<body>


    <div style="display: none;" bis_skin_checked="1">
        <!--?xml version="1.0" encoding="utf-8"?--><svg xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink">
            <symbol viewBox="0 0 20 20" id="action" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.82 13H3a1 1 0 0 1-.78-1.625l8-10c.643-.804 1.936-.227 1.766.79L11.18 7H17a1 1 0 0 1 .78 1.625l-8 10c-.643.804-1.936.227-1.766-.79L8.82 13zm-3.74-2H10a1 1 0 0 1 .986 1.164l-.368 2.213L14.919 9H10a1 1 0 0 1-.986-1.164l.368-2.213L5.081 11z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="add" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19a9 9 0 1 1 0-18 9 9 0 0 1 0 18zm1-10V5.833c0-.46-.448-.833-1-.833s-1 .373-1 .833V9H5.833C5.373 9 5 9.448 5 10s.373 1 .833 1H9v3.167c0 .46.448.833 1 .833s1-.373 1-.833V11h3.167c.46 0 .833-.448.833-1s-.373-1-.833-1H11zm-1 8c4.067 0 7-2.933 7-7s-2.933-7-7-7-7 2.933-7 7 2.933 7 7 7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="add--large" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 24C6.925 24 2 19.075 2 13S6.925 2 13 2s11 4.925 11 11-4.925 11-11 11zm0-2a9 9 0 1 0 0-18 9 9 0 0 0 0 18z">
                </path>
                <path d="M12 8a1 1 0 0 1 2 0v10a1 1 0 0 1-2 0V8z"></path>
                <path d="M8 14a1 1 0 0 1 0-2h10a1 1 0 0 1 0 2H8z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="add--simple" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11 9h5.167c.46 0 .833.448.833 1s-.373 1-.833 1H11v5.167c0 .46-.448.833-1 .833s-1-.373-1-.833V11H3.833C3.373 11 3 10.552 3 10s.373-1 .833-1H9V3.833C9 3.373 9.448 3 10 3s1 .373 1 .833V9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="advances" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8 11.215l-5.174 3.547a1.272 1.272 0 0 1-1.193.067c-.39-.183-.633-.545-.633-.945V6.062c0-.4.243-.762.633-.944.38-.179.837-.153 1.192.066L8 8.783V6.062c0-.4.243-.762.633-.944.38-.179.837-.153 1.192.066l5.665 3.94c.318.196.509.523.51.873a1.04 1.04 0 0 1-.508.88l-5.666 3.885a1.272 1.272 0 0 1-1.193.067c-.39-.183-.633-.545-.633-.945v-2.67zM18 5a1 1 0 0 1 1 1v8a1 1 0 0 1-2 0V6a1 1 0 0 1 1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="alert" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M1 10a9 9 0 1 0 18 0 9 9 0 0 0-18 0Zm16 0a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"></path>
                <path
                    d="M9.293 13.293a1 1 0 1 0 1.414 1.414 1 1 0 0 0-1.414-1.414ZM9.293 5.293A1 1 0 0 1 11 6v5a1 1 0 0 1-2 0V6a1 1 0 0 1 .293-.707Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="android" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7.096 1.011c-.047.009-.095.017-.136.046a.37.37 0 0 0-.09.51l.78 1.168c-1.205.64-2.104 1.706-2.397 2.983h9.995c-.292-1.277-1.191-2.342-2.397-2.983l.78-1.168a.37.37 0 0 0-.09-.51.37.37 0 0 0-.509.102l-.86 1.27a5.583 5.583 0 0 0-3.844 0l-.859-1.27a.363.363 0 0 0-.373-.148zm1.165 2.892a.544.544 0 1 1-.002 1.088.544.544 0 0 1 .002-1.088zm3.98 0c.3 0 .542.244.542.545a.542.542 0 1 1-1.085 0c0-.301.243-.545.543-.545zM4.1 6.443c-.6 0-1.086.488-1.086 1.09v5.08c0 .601.487 1.089 1.086 1.089.127 0 .249-.027.362-.068V6.512a1.056 1.056 0 0 0-.362-.068zm1.085 0v7.984c0 .6.488 1.09 1.086 1.09h7.96a1.09 1.09 0 0 0 1.085-1.09V6.444H5.186zm11.216 0c-.127 0-.248.027-.362.069v7.122c.114.04.235.068.362.068.6 0 1.086-.488 1.086-1.089v-5.08c0-.602-.487-1.09-1.086-1.09zm-9.768 9.799v1.452c0 .8.648 1.451 1.447 1.451a1.45 1.45 0 0 0 1.447-1.451v-1.452H6.633zm4.341 0v1.452c0 .8.649 1.451 1.447 1.451a1.45 1.45 0 0 0 1.448-1.451v-1.452h-2.895z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="apple" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17.186 15.027a9.817 9.817 0 0 1-.958 1.74c-.503.726-.915 1.228-1.233 1.507-.493.458-1.02.692-1.585.706-.406 0-.895-.117-1.464-.354-.572-.235-1.097-.352-1.577-.352-.503 0-1.043.117-1.62.352-.579.237-1.045.36-1.401.372-.542.024-1.082-.217-1.621-.724-.344-.303-.775-.823-1.29-1.56-.553-.787-1.008-1.699-1.364-2.739-.382-1.123-.573-2.21-.573-3.264 0-1.206.258-2.247.774-3.118.406-.7.946-1.253 1.622-1.659A4.328 4.328 0 0 1 7.09 5.31c.43 0 .995.134 1.696.399.7.265 1.148.4 1.345.4.147 0 .646-.158 1.492-.471.8-.291 1.475-.412 2.027-.364 1.499.122 2.624.72 3.373 1.795-1.34.82-2.003 1.97-1.99 3.444.012 1.149.425 2.104 1.235 2.863.367.353.777.625 1.233.818-.099.29-.203.568-.314.834zM13.749 1.36c0 .9-.325 1.74-.973 2.519-.783.925-1.73 1.46-2.756 1.375a2.832 2.832 0 0 1-.021-.341c0-.865.372-1.79 1.033-2.546.33-.382.75-.7 1.259-.955.508-.25.988-.388 1.44-.412.013.12.018.24.018.36z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="approve" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M11.8437 2.15195C11.2724 1.95874 10.7142 1.95179 10.2068 2.11966C9.71041 2.28386 9.33191 2.59193 9.06203 2.92062C8.97528 3.02628 8.88398 3.17385 8.81762 3.28298C8.73828 3.41345 8.64282 3.57675 8.53773 3.75838C8.47271 3.87075 8.40349 3.99103 8.3305 4.11786C8.16351 4.40803 7.97641 4.73313 7.77513 5.0757C7.32877 5.8354 6.84787 6.61943 6.42418 7.21177C6.29539 7.15134 6.1516 7.11757 5.99992 7.11757H2.99992C2.44763 7.11757 1.99992 7.56529 1.99992 8.11757V16.0107C1.99992 16.563 2.44763 17.0107 2.99992 17.0107L5.99992 17.0107C6.04531 17.0107 6.09 17.0077 6.13379 17.0018C6.26361 17.0625 6.4026 17.1099 6.5496 17.1418C7.78847 17.4109 9.46008 17.682 10.9524 17.845C11.6985 17.9265 12.4159 17.9829 13.0211 17.9966C13.5769 18.0092 14.1856 17.9925 14.6192 17.8495C15.6588 17.5066 16.3045 16.6935 16.7086 15.9377C17.1157 15.1765 17.3504 14.3383 17.5026 13.7357C17.6593 13.1157 17.8694 12.1167 17.9577 11.1637C18.0017 10.6894 18.019 10.1908 17.9721 9.74063C17.9297 9.33365 17.8182 8.77227 17.4412 8.35458C17.1186 7.99708 16.6662 7.80396 16.2994 7.68835C15.9049 7.56401 15.458 7.48392 15.0125 7.43294C14.317 7.35336 13.5531 7.33687 12.858 7.36394C13.1163 6.41225 13.2861 5.44608 13.3623 5.01271C13.3811 4.90561 13.3942 4.83089 13.4015 4.79719C13.4948 4.3667 13.4196 3.84048 13.2083 3.38555C12.9819 2.89789 12.5507 2.39108 11.8437 2.15195ZM10.6203 4.16127L10.6194 4.1621C10.7003 4.06536 10.7775 4.01716 10.841 3.99616C10.8947 3.97841 11.0011 3.95804 11.1967 4.02419C11.2822 4.0531 11.3435 4.10932 11.391 4.21163C11.416 4.26549 11.4311 4.32166 11.4375 4.36829C11.4401 4.38665 11.4407 4.39933 11.4409 4.40634C11.4212 4.50101 11.3971 4.63619 11.3675 4.80223C11.2619 5.39453 11.0863 6.37947 10.7899 7.31867C10.6154 7.87154 10.7838 8.40696 11.0752 8.76939C11.3668 9.13193 11.8572 9.41524 12.4424 9.36963C13.1669 9.31318 14.041 9.3136 14.7827 9.39846C15.1545 9.44101 15.4637 9.50157 15.6923 9.57362C15.8219 9.61446 15.8956 9.64974 15.932 9.66934C15.9445 9.70885 15.967 9.79315 15.9827 9.94345C16.0109 10.2146 16.0042 10.5715 15.9661 10.983C15.8902 11.8015 15.7041 12.6948 15.5624 13.2558C15.4162 13.8341 15.2279 14.4754 14.9407 15.0125C14.6506 15.555 14.3308 15.8589 13.9867 15.9724C13.9838 15.9732 13.9631 15.979 13.9189 15.9861C13.8697 15.9941 13.8037 16.0019 13.719 16.0081C13.5486 16.0205 13.3302 16.0245 13.0669 16.0185C12.5409 16.0065 11.8861 15.9564 11.1719 15.8783C9.75895 15.724 8.1765 15.4675 7.01586 15.2173L7.03611 9.92842C7.03627 9.88673 7.05894 9.76358 7.17174 9.5553C7.27757 9.35989 7.42521 9.15817 7.57544 8.97999C8.19884 8.24057 8.92712 7.0523 9.50424 6.07003C9.71013 5.7196 9.90485 5.38127 10.0736 5.08814C10.1451 4.96381 10.2124 4.84684 10.2735 4.74132C10.3779 4.56091 10.4641 4.41362 10.5314 4.30294C10.5761 4.2295 10.6022 4.18944 10.6135 4.17203C10.6183 4.16471 10.6204 4.16139 10.6203 4.16127Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="arrow-down" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M2.318 8.769a1 1 0 011.413.049L9 14.463V3a1 1 0 112 0v11.463l5.269-5.645a1 1 0 011.462 1.364l-7 7.5a1 1 0 01-1.462 0l-7-7.5a1 1 0 01.049-1.413z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="arrow-left" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.414 11l5.293 5.293a1 1 0 0 1-1.414 1.414l-7-7a1 1 0 0 1 0-1.414l7-7a1 1 0 1 1 1.414 1.414L5.414 9H17a1 1 0 0 1 0 2H5.414z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="arrow-right" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14.586 9L9.293 3.707a1 1 0 0 1 1.414-1.414l7 7a1 1 0 0 1 0 1.414l-7 7a1 1 0 1 1-1.414-1.414L14.586 11H3a1 1 0 1 1 0-2h11.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="arrow-up" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M2.318 11.231a1 1 0 001.413-.049L9 5.537V17a1 1 0 102 0V5.537l5.269 5.645a1 1 0 101.462-1.364l-7-7.5a1 1 0 00-1.462 0l-7 7.5a1 1 0 00.049 1.413z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="attachment" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.722 9.496a.75.75 0 0 1 1.055-.008.737.737 0 0 1 .009 1.048l-6.86 6.919a5.203 5.203 0 0 1-7.4 0 5.286 5.286 0 0 1 0-7.432l6.86-6.92a3.719 3.719 0 0 1 5.287 0 3.77 3.77 0 0 1 0 5.302l-6.866 6.92c-.875.883-2.3.883-3.176 0a2.254 2.254 0 0 1 0-3.172l6.337-6.384a.75.75 0 0 1 1.055-.008.737.737 0 0 1 .008 1.048l-6.336 6.385a.779.779 0 0 0 0 1.09.734.734 0 0 0 1.049 0l6.866-6.919c.88-.888.88-2.333 0-3.221a2.219 2.219 0 0 0-3.16 0l-6.86 6.919a3.81 3.81 0 0 0 0 5.352 3.703 3.703 0 0 0 5.273 0l6.859-6.92z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="attention" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7.916 3.222C8.369 2.453 9.153 2 10 2c.848 0 1.632.453 2.085 1.222l6.594 12.196c.426.758.428 1.689.006 2.449-.424.765-1.147 1.122-2.084 1.133H3.391c-.928-.01-1.65-.368-2.075-1.133a2.51 2.51 0 0 1 0-2.436l6.6-12.21zm-4.76 12.904a.717.717 0 0 0-.002.696c.063.114.21.174.557.178h12.46c.356-.004.502-.064.565-.178a.723.723 0 0 0-.008-.708L10.564 4.298A.657.657 0 0 0 10 3.97a.656.656 0 0 0-.557.317l-6.287 11.84zM10 14a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm0-6a1 1 0 0 1 1 1v3a1 1 0 0 1-2 0V9a1 1 0 0 1 1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="back" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13.813 16.187a1.15 1.15 0 0 1-1.626 1.626l-7-7a1.15 1.15 0 0 1 0-1.626l7-7a1.15 1.15 0 0 1 1.626 1.626L7.626 10l6.187 6.187z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="badge" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M7 2a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1H8a1 1 0 01-1-1V2zm2 1v1h2V3H9z"></path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M3 4a1 1 0 011-1h3a1 1 0 010 2H5v12h10V5h-2a1 1 0 110-2h3a1 1 0 011 1v14a1 1 0 01-1 1H4a1 1 0 01-1-1V4z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M10 9a1 1 0 100 2 1 1 0 000-2zm-3 1a3 3 0 116 0 3 3 0 01-6 0zm0 5a1 1 0 011-1h4a1 1 0 110 2H8a1 1 0 01-1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="balance" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M4.5 8a.5.5 0 100 1 .5.5 0 000-1zM2 8.5a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0zM15.5 8a.5.5 0 100 1 .5.5 0 000-1zm-2.5.5a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0zM10 2a1 1 0 011 1v13a1 1 0 11-2 0V3a1 1 0 011-1z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM2 17a1 1 0 011-1h14a1 1 0 110 2H3a1 1 0 01-1-1z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M6 16a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="bank" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18.085 17c.506 0 .917.448.917 1s-.41 1-.917 1H1.918c-.506 0-.916-.448-.916-1s.41-1 .916-1h16.167zM4 11a1 1 0 1 1 2 0v4a1 1 0 0 1-2 0v-4zm5 0a1 1 0 1 1 2 0v4a1 1 0 0 1-2 0v-4zm5 0a1 1 0 0 1 2 0v4a1 1 0 0 1-2 0v-4zM1.392 7.122l8.25-6a.59.59 0 0 1 .719 0l8.25 6c.682.496.418 1.878-.359 1.878h-16.5C.973 9 .71 7.618 1.391 7.122zM15.08 7l-5.078-3.86L4.923 7H15.08z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="bar-graph" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M4.8 17H3.2c-.7 0-1.2-.5-1.2-1.2v-3.6c0-.7.5-1.2 1.2-1.2h1.6c.7 0 1.2.5 1.2 1.2v3.6c0 .7-.5 1.2-1.2 1.2zm6.1 0H9.1c-.6 0-1.1-.5-1.1-1.1V8.1C8 7.5 8.5 7 9.1 7h1.8c.6 0 1.1.5 1.1 1.1v7.8c0 .6-.5 1.1-1.1 1.1zm6.1 0h-2c-.6 0-1-.4-1-1V4c0-.6.4-1 1-1h2c.6 0 1 .4 1 1v12c0 .6-.4 1-1 1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="briefcase" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15.5 5H14V4c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v1H4.5C3.1 5 2 6.1 2 7.5v8C2 16.9 3.1 18 4.5 18h11c1.4 0 2.5-1.1 2.5-2.5v-8C18 6.1 16.9 5 15.5 5zM8 4h4v1H8V4zm8 11.5c0 .3-.2.5-.5.5h-11c-.3 0-.5-.2-.5-.5V11h4v1h4v-1h4v4.5zM16 9H4V7.5c0-.3.2-.5.5-.5h11c.3 0 .5.2.5.5V9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="business" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12 19H2.5c-.8 0-1.5-.7-1.5-1.5v-15C1 1.7 1.7 1 2.5 1h9c.8 0 1.5.7 1.5 1.5V18c0 .6-.4 1-1 1zm-8.3-2h6.6c.4 0 .7-.3.7-.7V3.7c0-.4-.3-.7-.7-.7H3.7c-.4 0-.7.3-.7.7v12.6c0 .4.3.7.7.7z">
                </path>
                <path
                    d="M17.5 19H12c-.6 0-1-.4-1-1V6.5c0-.8.7-1.5 1.5-1.5h5c.8 0 1.5.7 1.5 1.5v11c0 .8-.7 1.5-1.5 1.5zm-3.8-2h2.6c.4 0 .7-.3.7-.7V7.7c0-.4-.3-.7-.7-.7h-2.6c-.4 0-.7.3-.7.7v8.6c0 .4.3.7.7.7zM5.5 6h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm4 0h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5z">
                </path>
                <path
                    d="M15.5 10h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm0 3h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm0 3h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm-10-7h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm4 0h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm-4 3h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zm4 0h-1c-.3 0-.5-.2-.5-.5v-1c0-.3.2-.5.5-.5h1c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5zM9 17H5v-3.6c0-.2.2-.4.4-.4h3.1c.3 0 .5.2.5.4V17z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="camera" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14.414 5H16a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h1.586l1.707-1.707A1 1 0 0 1 8 3h4a1 1 0 0 1 .707.293L14.414 5zm-6 0L6.707 6.707A1 1 0 0 1 6 7H4a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-2a1 1 0 0 1-.707-.293L11.586 5H8.414zM10 15a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-2a2 2 0 1 0 0-4 2 2 0 0 0 0 4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="cancel" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11.592 10l5.078 5.078a1.126 1.126 0 0 1-1.592 1.592L10 11.592 4.922 16.67a1.126 1.126 0 1 1-1.592-1.592L8.408 10 3.33 4.922A1.126 1.126 0 0 1 4.922 3.33L10 8.408l5.078-5.078a1.126 1.126 0 0 1 1.592 1.592L11.592 10z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="cart" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M4.295 4.29a1 1 0 01.835-.282l13 1.7a1 1 0 01.858 1.149l-1 6.3A1 1 0 0117 14H6a1 1 0 01-.992-.876l-1-8a1 1 0 01.287-.833zm1.858 1.87l.73 5.84h9.263l.705-4.442L6.153 6.16z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M1 3a1 1 0 011-1h2a1 1 0 01.894.553l1 2a1 1 0 01-1.788.894L3.382 4H2a1 1 0 01-1-1z"></path>
                <path d="M6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm9 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="categorize" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M9 16v-3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2Zm-2-3H4v3h3v-3Zm9-9h-3v3h3V4Zm0 9h-3v3h3v-3Zm-5-9a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V4Zm2 7a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-3ZM6 8.914A1 1 0 0 1 4.587 7.5l.793-.793H2.793a1 1 0 0 1 0-2h2.586l-.793-.793A1 1 0 0 1 6 2.5L8.5 5a1 1 0 0 1 0 1.414L6 8.914Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="category" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M7 4H4v3h3V4Zm2 12v-3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2Zm0-9V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2Zm-2 6H4v3h3v-3Zm9-9h-3v3h3V4Zm0 9h-3v3h3v-3Zm-5-9a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V4Zm2 7a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-3Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="check" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7 14.586L17.293 4.293a1 1 0 0 1 1.414 1.414l-11 11a1 1 0 0 1-1.414 0l-5-5a1 1 0 0 1 1.414-1.414L7 14.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="checklist" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18 6h-8c-.6 0-1-.4-1-1s.4-1 1-1h8c.6 0 1 .4 1 1s-.4 1-1 1zm0 6h-8c-.6 0-1-.4-1-1s.4-1 1-1h8c.6 0 1 .4 1 1s-.4 1-1 1zm0 6h-8c-.6 0-1-.4-1-1s.4-1 1-1h8c.6 0 1 .4 1 1s-.4 1-1 1zM3.5 7.5c-.3 0-.5-.1-.7-.3L1.3 5.7c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0l.8.8 2.8-2.8c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L4.2 7.2c-.2.2-.4.3-.7.3zm0 5.7c-.3 0-.5-.1-.7-.3l-1.5-1.4c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0l.8.8 2.7-2.7c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L4.2 13c-.2.2-.4.2-.7.2zm0 5.8c-.3 0-.5-.1-.7-.3l-1.5-1.5c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0l.8.8L6 14c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-3.2 3.2c-.2.3-.4.4-.7.4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="close-menu" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M6.18 12.249c-.348.426-.175.772.376.772h6.905c.556 0 .727-.342.377-.772L10.64 8.321c-.35-.426-.91-.43-1.26 0l-3.2 3.928z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="coin" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19c-5 0-9-4-9-9s4-9 9-9 9 4 9 9-4 9-9 9zm0-16c-3.9 0-7 3.1-7 7s3.1 7 7 7 7-3.1 7-7-3.1-7-7-7z">
                </path>
                <path
                    d="M11 14H8c-.6 0-1-.4-1-1s.4-1 1-1h3c.4 0 .5-.3.5-.5s-.1-.5-.5-.5H9c-1.6 0-2.5-1.3-2.5-2.5S7.4 6 9 6h3c.6 0 1 .4 1 1s-.4 1-1 1H9c-.4 0-.5.3-.5.5s.1.5.5.5h2c1.6 0 2.5 1.3 2.5 2.5S12.6 14 11 14z">
                </path>
                <path
                    d="M10 8c-.6 0-1-.4-1-1V5c0-.6.4-1 1-1s1 .4 1 1v2c0 .6-.4 1-1 1zm0 8c-.6 0-1-.4-1-1v-2c0-.6.4-1 1-1s1 .4 1 1v2c0 .6-.4 1-1 1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="collapse" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3.813 14.813a1.15 1.15 0 0 1-1.626-1.626l7-7a1.15 1.15 0 0 1 1.626 0l7 7a1.15 1.15 0 0 1-1.626 1.626L10 8.626l-6.187 6.187z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="collapse-diagonal" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17.2793 4.15575C17.6219 3.81321 17.583 3.21894 17.1924 2.82842C16.8019 2.43789 16.2076 2.39899 15.8651 2.74153L12.5356 6.07106V4.24263C12.5356 3.69035 12.0879 3.24263 11.5356 3.24263C10.9833 3.24263 10.5356 3.69035 10.5356 4.24263L10.5356 8.48527C10.5356 9.03756 10.9833 9.48527 11.5356 9.48527L15.7782 9.48527C16.3305 9.48527 16.7782 9.03756 16.7782 8.48527C16.7782 7.93299 16.3305 7.48527 15.7782 7.48527L13.9498 7.48527L17.2793 4.15575Z">
                </path>
                <path
                    d="M2.74153 15.8651C2.39899 16.2076 2.43789 16.8019 2.82842 17.1924C3.21894 17.5829 3.81321 17.6218 4.15575 17.2793L7.48527 13.9497L7.48527 15.7782C7.48527 16.3305 7.93299 16.7782 8.48527 16.7782C9.03756 16.7782 9.48527 16.3305 9.48527 15.7782L9.48527 11.5355C9.48527 10.9832 9.03756 10.5355 8.48527 10.5355H4.24263C3.69035 10.5355 3.24263 10.9832 3.24263 11.5355C3.24263 12.0878 3.69035 12.5355 4.24263 12.5355H6.07106L2.74153 15.8651Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="comment" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M1 6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3h-3.586l-3.707 3.707A1 1 0 0 1 7 18v-3H4a3 3 0 0 1-3-3V6zm3-1a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h4a1 1 0 0 1 1 1v1.586l2.293-2.293A1 1 0 0 1 12 13h4a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H4z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="confetti" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.48 12.586a1.004 1.004 0 0 0-.972-.828c-.09-.002-2.244-.063-4.475-2.293-2.52-2.521-2.312-4.27-2.312-4.27a.998.998 0 0 0-1.915-.551L2.204 16.71A.998.998 0 0 0 3.494 18l12.36-4.306a.996.996 0 0 0 .626-1.106v-.002ZM4.861 15.341 7.58 8.242c.436.789 1.083 1.679 2.04 2.637.94.94 1.89 1.574 2.74 2l-7.498 2.462Z">
                </path>
                <path
                    d="M10.5 5.999a.997.997 0 0 0 .707-.293C12.464 4.449 12.5 3.242 12.5 2.995a1 1 0 0 0-.997-.999c-.583.036-1 .445-1.003.996-.002.415-.137.73-.707 1.3a.999.999 0 0 0 .707 1.707ZM17.334 8.242c-.138-.046-.795-.271-2.387.518a1 1 0 0 0 .89 1.792c.827-.411.828-.421.881-.406a1 1 0 0 0 .615-1.904h.001ZM16.496 4.913a.997.997 0 0 0 .707-.293l.5-.5a.999.999 0 1 0-1.414-1.414l-.5.5a.999.999 0 0 0 .707 1.707ZM3.204 8.242c.13 0 .26-.03.38-.08s.23-.12.33-.21c.09-.101.16-.21.21-.33.05-.12.08-.25.08-.38s-.03-.26-.08-.38-.12-.23-.21-.33c-.05-.04-.1-.09-.15-.12a.757.757 0 0 0-.18-.09.93.93 0 0 0-.76 0 .763.763 0 0 0-.18.09c-.05.03-.1.08-.15.12-.09.1-.16.2-.21.33a.995.995 0 0 0 .21 1.09.99.99 0 0 0 .71.29ZM11.793 8.706a.997.997 0 0 0 1.414 0l1.996-2.086a.999.999 0 1 0-1.414-1.414l-1.996 2.086a.999.999 0 0 0 0 1.414ZM16.964 16.71c.13 0 .26-.03.38-.08s.229-.12.33-.21c.09-.101.16-.21.21-.33.05-.12.08-.25.08-.38s-.03-.26-.08-.38-.12-.23-.21-.33c-.05-.04-.101-.09-.15-.12a.757.757 0 0 0-.18-.09.93.93 0 0 0-.76 0 .763.763 0 0 0-.181.09c-.05.03-.1.08-.149.12-.09.1-.16.2-.21.33a.995.995 0 0 0 .21 1.09.99.99 0 0 0 .71.29Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="copy" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 5V3h1a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h1v2H6a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-1zM8 1h4a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 2v2h4V3H8z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="creditcard" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17 6v-.545A.455.455 0 0 0 16.545 5H3.5a.5.5 0 0 0-.5.5V6h14zm0 2H3v6.545c0 .251.204.455.455.455h13.09a.455.455 0 0 0 .455-.455V8zM3.5 3h13.045A2.455 2.455 0 0 1 19 5.455v9.09A2.455 2.455 0 0 1 16.545 17H3.455A2.455 2.455 0 0 1 1 14.545V5.5A2.5 2.5 0 0 1 3.5 3zM5 13a1 1 0 1 1 0-2h5a1 1 0 1 1 0 2H5z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="customize" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10.17 4H3a1 1 0 0 0 0 2h7.17a3.001 3.001 0 0 0 5.66 0H17a1 1 0 1 0 0-2h-1.17a3.001 3.001 0 0 0-5.66 0zm2.838 0h-.016a1.02 1.02 0 0 1 .016 0z"
                    clip-rule="evenodd"></path>
                <path
                    d="M4.17 9H3a1 1 0 0 0 0 2h1.17a3.001 3.001 0 0 0 5.66 0H17a1 1 0 1 0 0-2H9.83a3.001 3.001 0 0 0-5.66 0zm2.838 0h-.016a1.036 1.036 0 0 1 .016 0z"
                    clip-rule="evenodd"></path>
                <path
                    d="M10.17 14H3a1 1 0 1 0 0 2h7.17a3.001 3.001 0 0 0 5.66 0H17a1 1 0 1 0 0-2h-1.17a3.001 3.001 0 0 0-5.66 0zm2.838 0h-.016.016z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="date" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16 7V5.5a.5.5 0 0 0-.5-.5H14a1 1 0 0 1-2 0H8a1 1 0 1 1-2 0H4.5a.5.5 0 0 0-.5.5V7h12zm0 2H4v7.5a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 .5-.5V9zM8 3h4V2a1 1 0 0 1 2 0v1h1.5A2.5 2.5 0 0 1 18 5.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 2 16.5v-11A2.5 2.5 0 0 1 4.5 3H6V2a1 1 0 1 1 2 0v1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="decreased" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17 11.586V10a1 1 0 0 1 2 0v4a1 1 0 0 1-1 1h-4a1 1 0 0 1 0-2h1.586L11.5 8.914l-3.293 3.293a1 1 0 0 1-1.414 0l-5.5-5.5a1 1 0 1 1 1.414-1.414L7.5 10.086l3.293-3.293a1 1 0 0 1 1.414 0L17 11.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="delete" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5 4c0-1.496 1.397-3 3-3h4c1.603 0 3 1.504 3 3h2a1 1 0 0 1 0 2v10.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 3 16.5V6a1 1 0 1 1 0-2h2zm2 0h6c0-.423-.536-1-1-1H8c-.464 0-1 .577-1 1zM5 6v10.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V6H5zm2 3a1 1 0 1 1 2 0v5a1 1 0 0 1-2 0V9zm4 0a1 1 0 1 1 2 0v4.8a1 1 0 0 1-2 0V9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="desktop" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3.5 5a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5h-13zM11 16v1h2a1 1 0 0 1 0 2H7a1 1 0 0 1 0-2h2v-1H3.5A2.5 2.5 0 0 1 1 13.5v-8A2.5 2.5 0 0 1 3.5 3h13A2.5 2.5 0 0 1 19 5.5v8a2.5 2.5 0 0 1-2.5 2.5H11z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="disapprove" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M8.15624 17.848C8.72749 18.0413 9.28571 18.0482 9.79317 17.8803C10.2895 17.7161 10.668 17.4081 10.9379 17.0794C11.0247 16.9737 11.116 16.8261 11.1823 16.717C11.2617 16.5865 11.3571 16.4233 11.4622 16.2416C11.5272 16.1292 11.5964 16.009 11.6694 15.8821C11.8364 15.592 12.0235 15.2669 12.2248 14.9243C12.6712 14.1646 13.1521 13.3806 13.5758 12.7882C13.7046 12.8487 13.8483 12.8824 14 12.8824H17C17.5523 12.8824 18 12.4347 18 11.8824V3.98929C18 3.437 17.5523 2.98929 17 2.98929L14 2.98929C13.9546 2.98929 13.9099 2.99231 13.8661 2.99817C13.7363 2.93746 13.5973 2.89007 13.4503 2.85815C12.2115 2.58914 10.5399 2.31805 9.04756 2.15499C8.30146 2.07346 7.58408 2.01714 6.97887 2.00341C6.42306 1.9908 5.81436 2.00753 5.38075 2.15052C4.34115 2.49335 3.69547 3.30654 3.29134 4.06229C2.88428 4.82351 2.64959 5.66171 2.4973 6.26433C2.34063 6.8843 2.13056 7.88335 2.04224 8.83634C1.99829 9.3106 1.98092 9.8092 2.02781 10.2594C2.0702 10.6663 2.18176 11.2277 2.55873 11.6454C2.88137 12.0029 3.33374 12.196 3.70056 12.3117C4.09507 12.436 4.54197 12.5161 4.98747 12.5671C5.68294 12.6466 6.44686 12.6631 7.1419 12.6361C6.8836 13.5878 6.71382 14.5539 6.63766 14.9873C6.61884 15.0944 6.60571 15.1691 6.59841 15.2028C6.50516 15.6333 6.58032 16.1595 6.7916 16.6144C7.01808 17.1021 7.44924 17.6089 8.15624 17.848ZM9.37967 15.8387L9.38051 15.8379C9.29959 15.9346 9.2224 15.9828 9.15893 16.0038C9.10526 16.0216 8.9988 16.042 8.80324 15.9758C8.71776 15.9469 8.65646 15.8907 8.60895 15.7884C8.58394 15.7345 8.56885 15.6783 8.56241 15.6317C8.55988 15.6134 8.55921 15.6007 8.55905 15.5937C8.57877 15.499 8.60287 15.3638 8.63247 15.1978C8.73806 14.6055 8.91365 13.6205 9.21009 12.6813C9.38459 12.1285 9.21616 11.593 8.92469 11.2306C8.63313 10.8681 8.14277 10.5848 7.55753 10.6304C6.833 10.6868 5.95891 10.6864 5.21726 10.6015C4.84539 10.559 4.53625 10.4984 4.30766 10.4264C4.17806 10.3855 4.10433 10.3503 4.0679 10.3307C4.05545 10.2911 4.03293 10.2068 4.01727 10.0566C3.98903 9.78542 3.99575 9.42849 4.03388 9.01699C4.10974 8.1985 4.29583 7.3052 4.43759 6.74422C4.58373 6.16589 4.77199 5.52462 5.05919 4.98755C5.34932 4.445 5.66918 4.14106 6.0132 4.02762C6.01612 4.0268 6.03683 4.02104 6.08103 4.01386C6.13023 4.00586 6.19623 3.99807 6.28091 3.9919C6.45135 3.97948 6.66977 3.97555 6.93302 3.98152C7.45902 3.99345 8.11382 4.04362 8.828 4.12166C10.241 4.27605 11.8234 4.53249 12.9841 4.78267L12.9638 10.0716C12.9637 10.1133 12.941 10.2364 12.8282 10.4447C12.7224 10.6401 12.5747 10.8418 12.4245 11.02C11.8011 11.7594 11.0728 12.9477 10.4957 13.93C10.2898 14.2804 10.0951 14.6187 9.92638 14.9119C9.85482 15.0362 9.78751 15.1532 9.72645 15.2587C9.62207 15.4391 9.53583 15.5864 9.46853 15.6971C9.42387 15.7705 9.39778 15.8106 9.38644 15.828C9.38167 15.8353 9.37951 15.8386 9.37967 15.8387Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="document" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 4.414V6h1.586L13 4.414zM16 8h-4a1 1 0 0 1-1-1V3H5.5a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h10a.5.5 0 0 0 .5-.5V8zm-4-7a1 1 0 0 1 .707.293l5 5A1 1 0 0 1 18 7v9.5a2.5 2.5 0 0 1-2.5 2.5h-10A2.5 2.5 0 0 1 3 16.5v-13A2.5 2.5 0 0 1 5.5 1H12zm2 9a1 1 0 0 1 0 2H7a1 1 0 0 1 0-2h7zm0 3a1 1 0 0 1 0 2H7a1 1 0 0 1 0-2h7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="download" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11 15.586l1.293-1.293a1 1 0 0 1 1.414 1.414l-3 3a1 1 0 0 1-1.414 0l-3-3a1 1 0 0 1 1.414-1.414L9 15.586V9.877C9 9.393 9.448 9 10 9s1 .393 1 .877v5.709zm3.465-8.828c1.989-.001 3.737 1.359 4.327 3.342.586 1.968-.095 4.115-1.698 5.314a.812.812 0 1 1-.972-1.3c1.052-.786 1.509-2.227 1.115-3.55-.39-1.308-1.515-2.184-2.772-2.182h-.937a.812.812 0 0 1-.789-.622c-.535-2.218-2.287-3.843-4.393-4.101-2.1-.257-4.142.895-5.132 2.915-1 2.04-.712 4.53.716 6.247a.812.812 0 1 1-1.248 1.038c-1.839-2.211-2.205-5.387-.925-8 1.29-2.63 3.988-4.154 6.786-3.811 2.586.317 4.743 2.164 5.596 4.71h.326z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="drag" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7 3h2v2H7V3zm0 4h2v2H7V7zm4-4h2v2h-2V3zm0 4h2v2h-2V7zm-4 4h2v2H7v-2zm4 0h2v2h-2v-2zm-4 4h2v2H7v-2zm4 0h2v2h-2v-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="duplicate" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M9.5 9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5h-7zm0-2h7A2.5 2.5 0 0 1 19 9.5v7a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 7 16.5v-7A2.5 2.5 0 0 1 9.5 7zM4 11a1 1 0 0 1 0 2h-.5A2.5 2.5 0 0 1 1 10.5v-7A2.5 2.5 0 0 1 3.5 1h7A2.5 2.5 0 0 1 13 3.5V4a1 1 0 0 1-2 0v-.5a.5.5 0 0 0-.5-.5h-7a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .5.5H4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="edit" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.75 13.836L16.586 6 14 3.414 6.164 11.25l2.586 2.586zm-1.528 1.3l-2.358-2.358-.59 2.947 2.948-.59zm11.485-8.429l-10 10a1 1 0 0 1-.51.274l-5 1a1 1 0 0 1-1.178-1.177l1-5a1 1 0 0 1 .274-.511l10-10a1 1 0 0 1 1.414 0l4 4a1 1 0 0 1 0 1.414z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="error" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11.414 10l2.293 2.293a1 1 0 0 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 1 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10zM10 19a9 9 0 1 1 0-18 9 9 0 0 1 0 18zm0-2a7 7 0 1 0 0-14 7 7 0 0 0 0 14z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="expand" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 12.586l6.293-6.293a1 1 0 0 1 1.414 1.414l-7 7a1 1 0 0 1-1.414 0l-7-7a1 1 0 0 1 1.414-1.414L10 12.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="expand-diagonal" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10.8285 9.19238C10.4379 8.80185 10.399 8.20759 10.7416 7.86505L14.0711 4.53552L12.2427 4.53552C11.6904 4.53552 11.2427 4.08781 11.2427 3.53552C11.2427 2.98324 11.6904 2.53552 12.2427 2.53552H16.4853C17.0376 2.53552 17.4853 2.98324 17.4853 3.53552L17.4853 7.77816C17.4853 8.33045 17.0376 8.77816 16.4853 8.77816C15.933 8.77816 15.4853 8.33045 15.4853 7.77816L15.4853 5.94974L12.1558 9.27926C11.8133 9.6218 11.219 9.5829 10.8285 9.19238Z">
                </path>
                <path
                    d="M9.19238 10.8284C9.5829 11.2189 9.6218 11.8132 9.27926 12.1557L5.94974 15.4853H7.77816C8.33045 15.4853 8.77816 15.933 8.77816 16.4853C8.77816 17.0376 8.33045 17.4853 7.77816 17.4853L3.53552 17.4853C2.98324 17.4853 2.53552 17.0376 2.53552 16.4853V12.2426C2.53552 11.6903 2.98324 11.2426 3.53552 11.2426C4.08781 11.2426 4.53552 11.6903 4.53552 12.2426L4.53552 14.0711L7.86505 10.7415C8.20759 10.399 8.80185 10.4379 9.19238 10.8284Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="facebook" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M2.995 1A1.995 1.995 0 0 0 1 2.995v14.01C1 18.107 1.896 19 2.997 19H10v-7.5H7.75V9.25H10V7c0-1.875.75-3 3-3h2.25v2.25h-.975C13.6 6.25 13 6.85 13 7.525V9.25h3l-.375 2.25H13V19h4.002A1.996 1.996 0 0 0 19 17.005V2.995A1.995 1.995 0 0 0 17.005 1H2.995z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="filter" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12.085 15c.506 0 .917.448.917 1s-.41 1-.917 1H7.918c-.506 0-.916-.448-.916-1s.41-1 .916-1h4.167zm2-4c.506 0 .917.448.917 1s-.41 1-.917 1H5.918c-.506 0-.916-.448-.916-1s.41-1 .916-1h8.167zm2-4c.506 0 .917.448.917 1s-.41 1-.917 1H3.918c-.506 0-.916-.448-.916-1s.41-1 .916-1h12.167zm2-4c.506 0 .917.448.917 1s-.41 1-.917 1H1.918c-.506 0-.916-.448-.916-1s.41-1 .916-1h16.167z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="forward" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12.586 10L6.293 3.707a1 1 0 0 1 1.414-1.414l7 7a1 1 0 0 1 0 1.414l-7 7a1 1 0 1 1-1.414-1.414L12.586 10z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="gift" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.88 5.02c.62 0 1.11.5 1.11 1.11v3.76c0 .57-.43 1.04-.99 1.1v5.74c0 .7-.57 1.27-1.27 1.27H4.26c-.7 0-1.27-.57-1.27-1.27v-5.74c-.56-.06-.99-.53-.99-1.1V6.13c0-.61.5-1.11 1.11-1.11H5V5c0-.97 0-3 2-3 .95 0 2.16.89 3 1.62.84-.73 2.05-1.62 3-1.62 2 0 2 2.03 2 3v.02h1.88zM11 9h4.99V7.02H11V9zm0 7h4v-5h-4v5zM4 9h5V7.02H4V9zm.99 7H9v-5H4.99v5z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="heart" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11.527 5.12L9.999 6.924 8.473 5.12C6.206 2.435 2.767 4.928 4.44 8.923A17.595 17.595 0 0 0 10 15.751a17.556 17.556 0 0 0 5.545-6.797c1.673-4.034-1.752-6.51-4.02-3.834zm5.852 4.637a19.556 19.556 0 0 1-6.854 8.07.889.889 0 0 1-1.049 0 19.556 19.556 0 0 1-6.853-8.07C-.008 3.48 6.32-.528 10 3.827c3.689-4.355 10.009-.337 7.378 5.93z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="help" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19a9 9 0 1 1 0-18 9 9 0 0 1 0 18zm0-2a7 7 0 1 0 0-14 7 7 0 0 0 0 14zm0-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2zM8.543 7.936a1 1 0 1 1-1.886-.664 3.4 3.4 0 0 1 6.607 1.132c0 1.105-.646 1.965-1.645 2.632a6.249 6.249 0 0 1-1.439.716 1 1 0 1 1-.632-1.897 4.594 4.594 0 0 0 .962-.483c.5-.334.754-.673.754-.97a1.4 1.4 0 0 0-2.72-.466z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="help--simple" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M8.985 12.893c0 .6.4 1.001 1.002 1.001s1.003-.4 1.003-1.001c0-.902.601-1.402 1.604-2.203C13.697 9.889 15 8.887 15 6.884c0-2.303-1.303-4.005-3.309-4.606-2.406-.801-5.213.2-6.516 2.103-.3.5-.2 1.101.2 1.402.502.3 1.103.2 1.404-.3.802-1.202 2.707-1.803 4.21-1.302.803.2 2.006.8 2.006 2.703 0 1.002-.602 1.502-1.604 2.203-1.103.802-2.406 1.803-2.406 3.806zm2.506 3.605a1.503 1.503 0 11-3.006-.002 1.503 1.503 0 013.006.002z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="home" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 17h2.444c.3 0 .556-.262.556-.6V8.08l-6-4.8-6 4.8v8.32c0 .338.255.6.556.6H7v-6a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v6zm-2 0v-5H9v5h2zM2.375 6.82l7-5.6a1 1 0 0 1 1.25 0l7 5.6A1 1 0 0 1 18 7.6v8.8c0 1.43-1.138 2.6-2.556 2.6H4.556C3.138 19 2 17.83 2 16.4V7.6a1 1 0 0 1 .375-.78z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="id-card" xmlns="http://www.w3.org/2000/svg">
                <path clip-rule="evenodd"
                    d="M4 3h12a3 3 0 013 3v8a3 3 0 01-3 3H4a3 3 0 01-3-3V6a3 3 0 013-3zm0 2a1 1 0 00-1 1v8a1 1 0 001 1h12a1 1 0 001-1V6a1 1 0 00-1-1H4z">
                </path>
                <path clip-rule="evenodd"
                    d="M7.5 11a3.545 3.545 0 013.425 2.508c.074.266-.149.492-.425.492h-6c-.276 0-.5-.226-.425-.492A3.545 3.545 0 017.5 11z">
                </path>
                <path d="M9 8.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="image" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17 10.554V5a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 .6.916l8.81-8.062a.8.8 0 0 1 1.028-.043L17 10.554zm0 2.019l-4.006-3.085L5.878 16H16a1 1 0 0 0 1-1v-2.427zM4 2h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3zm2.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="increased" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15.586 7H13.5a1 1 0 0 1 0-2H18a1 1 0 0 1 1 1v4.5a1 1 0 0 1-2 0V8.414l-4.293 4.293a1 1 0 0 1-1.414 0L8 9.414l-5.293 5.293a1 1 0 0 1-1.414-1.414l6-6a1 1 0 0 1 1.414 0L12 10.586 15.586 7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="info" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M1 10C1 14.9706 5.02944 19 10 19C14.9706 19 19 14.9706 19 10C19 5.02944 14.9706 1 10 1C5.02944 1 1 5.02944 1 10ZM17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z">
                </path>
                <path d="M8 9C8 8.44772 8.44772 8 9 8H10V9C10 9.55228 9.55228 10 9 10C8.44772 10 8 9.55228 8 9Z"></path>
                <path
                    d="M8 14C8 13.4477 8.44772 13 9 13H11C11.5523 13 12 13.4477 12 14C12 14.5523 11.5523 15 11 15H9C8.44772 15 8 14.5523 8 14Z">
                </path>
                <path
                    d="M9 6C9 5.44772 9.44771 5 10 5C10.5523 5 11 5.44772 11 6C11 6.55228 10.5523 7 10 7C9.44771 7 9 6.55228 9 6Z">
                </path>
                <path
                    d="M10 8C9.44771 8 9 8.44772 9 9V13C9 13.5523 9.44771 14 10 14C10.5523 14 11 13.5523 11 13V9C11 8.44772 10.5523 8 10 8Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="items" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M9 3.8v4.5c0 .4-.3.7-.8.7H3.8c-.5 0-.8-.3-.8-.8V3.8c0-.5.3-.8.8-.8h4.5c.4 0 .7.3.7.8zM16.2 9h-4.4c-.5 0-.8-.3-.8-.8V3.8c0-.5.3-.8.8-.8h4.5c.4 0 .7.3.7.8v4.5c0 .4-.3.7-.8.7zm-3.7-1.5h3v-3h-3v3zM9 11.8v4.5c0 .4-.3.7-.8.7H3.8c-.5 0-.8-.3-.8-.8v-4.4c0-.5.3-.8.8-.8h4.5c.4 0 .7.3.7.8zm8 0v4.5c0 .4-.3.8-.8.8h-4.4c-.5-.1-.8-.4-.8-.9v-4.4c0-.5.3-.8.8-.8h4.5c.4 0 .7.3.7.8z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="jump-to-top" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M2 2a1 1 0 011-1h14a1 1 0 110 2H3a1 1 0 01-1-1zm7.293 3.293a1 1 0 011.414 0l5 5a1 1 0 01-1.414 1.414L11 8.414V18a1 1 0 11-2 0V8.414l-3.293 3.293a1 1 0 01-1.414-1.414l5-5z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="launchpad" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10.5 10.7a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM2 18.4c-.6 0-1-.4-1-1 0-2.3 1.1-3.3 2-3.8.4-.2.8-.1 1.2.2l1.4 1.4c.3.3.4.8.2 1.2-.5.9-1.5 2-3.8 2zm1.4-2.5c-.1.1-.1.2-.2.3.1-.1.3-.1.3-.2l-.1-.1z">
                </path>
                <path
                    d="M7 15c-.3 0-.5-.1-.7-.3l-1.4-1.4c-.2-.2-.3-.5-.3-.8 0-.2.8-5.3 3.8-8.3C11.6 1 17.4 1 17.7 1c.6 0 1 .4 1 1 0 .2 0 6.1-3.1 9.2-3 3-8.1 3.8-8.3 3.8H7zm-.3-2.7l.7.7c1.3-.3 4.7-1.1 6.7-3.2 1.8-1.8 2.3-5 2.5-6.7-1.7.1-4.9.7-6.7 2.5-2.1 2-2.9 5.4-3.2 6.7z">
                </path>
                <path
                    d="M5.6 10.8c-.2 0-.3 0-.4-.1L2.4 9.3c-.4-.2-.6-.6-.6-1s.3-.8.7-.9L6.7 6c.6-.2 1.1.1 1.3.6.2.5-.1 1.1-.6 1.3l-2 .7.7.3c.5.2.7.8.4 1.3-.1.4-.5.6-.9.6zm5.7 7c-.4 0-.7-.2-.9-.6L9 14.5c-.2-.5 0-1.1.4-1.3.5-.2 1.1 0 1.3.4l.3.7.7-2c.2-.5.7-.8 1.3-.6.5.2.8.7.6 1.3l-1.4 4.2c-.1.3-.4.6-.9.6zM16 7.7c-.3 0-.5-.1-.7-.3l-3-3c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0l3 3c.4.4.4 1 0 1.4-.2.2-.4.3-.7.3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="light-bulb" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 2C6.7 2 4 4.7 4 8c0 2 1 3.9 2.7 5v3.1c0 .2.1.5.3.7l1.2 1.3c.2.2.5.3.7.3h2.2c.3 0 .6-.1.7-.3l1.2-1.3c.2-.2.3-.4.3-.7V13C15 11.9 16 10 16 8c0-3.3-2.7-6-6-6zm.6 14.4H9.3l-.6-.7V15h2.5v.7l-.6.7zm1.2-4.9c-.3.2-.5.5-.5.9v.6H8.8v-.6c0-.4-.2-.7-.5-.9C6.8 10.8 6 9.5 6 8c0-2.2 1.8-4 4-4s4 1.8 4 4c0 1.5-.8 2.8-2.2 3.5z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="link" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7.725 11.283A.82.82 0 0 1 9.04 10.3a3.282 3.282 0 0 0 4.95.354l2.45-2.451a3.282 3.282 0 0 0-4.631-4.65l-1.412 1.404A.82.82 0 1 1 9.24 3.793l1.42-1.411a4.922 4.922 0 0 1 6.95 6.97l-2.462 2.462a4.922 4.922 0 0 1-7.423-.531zm4.55-2.566a.82.82 0 0 1-1.314.983 3.282 3.282 0 0 0-4.95-.354l-2.45 2.451a3.282 3.282 0 0 0 .04 4.6 3.279 3.279 0 0 0 4.59.05l1.403-1.402a.82.82 0 1 1 1.16 1.16L9.34 17.618a4.922 4.922 0 0 1-6.95-6.97l2.46-2.462a4.922 4.922 0 0 1 7.424.531z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="linkedin" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M1 2.995C1 1.893 1.893 1 2.995 1h14.01C18.107 1 19 1.893 19 2.995v14.01A1.995 1.995 0 0 1 17.005 19H2.995A1.995 1.995 0 0 1 1 17.005V2.995zM6.25 16V7.75h-3V16h3zm-1.5-9.225c.9 0 1.5-.6 1.5-1.425 0-.75-.6-1.35-1.5-1.35s-1.5.6-1.5 1.425c0 .75.6 1.35 1.5 1.35zm12 9.225v-4.5c0-2.625-1.2-3.75-2.625-3.75s-2.175.525-2.625 1.2v-1.2h-3V16h3v-4.5c0-1.35.975-1.5 1.2-1.5.225 0 1.05.3 1.05 1.5V16h3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="location" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14.202 15.894a23.941 23.941 0 0 1-3.673 2.955 1 1 0 0 1-1.058 0 22.249 22.249 0 0 1-1.162-.808 23.941 23.941 0 0 1-2.511-2.147C3.438 13.564 2 11.1 2 8.545 2 4.363 5.596 1 10 1s8 3.363 8 7.545c0 2.555-1.438 5.02-3.798 7.349zm-3.705.543a21.967 21.967 0 0 0 2.3-1.967C14.814 12.48 16 10.446 16 8.545 16 5.498 13.328 3 10 3S4 5.498 4 8.545c0 1.9 1.187 3.936 3.202 5.925A21.967 21.967 0 0 0 10 16.796c.156-.11.322-.23.497-.36zM10 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="logout" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3 4a2 2 0 0 1 2-2h5a1 1 0 1 1 0 2H5v12h5a1 1 0 1 1 0 2H5a2 2 0 0 1-2-2V4zm4 6a1 1 0 0 1 1-1h5.586l-1.293-1.293a1 1 0 0 1 1.414-1.414l3 3a1 1 0 0 1 0 1.414l-3 3a1 1 0 0 1-1.414-1.414L13.586 11H8a1 1 0 0 1-1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="logout--large" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M11.3 21a1 1 0 0 1 0 2H6.8A2.8 2.8 0 0 1 4 20.2V5.8A2.8 2.8 0 0 1 6.8 3h4.5a1 1 0 1 1 0 2H6.8a.8.8 0 0 0-.8.8v14.4a.8.8 0 0 0 .8.8h4.5zM17.35 10.76a1 1 0 1 1 1.3-1.52l3.6 3.086a1 1 0 0 1 0 1.519l-3.6 3.086a1 1 0 0 1-1.3-1.519l2.713-2.326-2.714-2.327z">
                </path>
                <path d="M20.8 12a1 1 0 0 1 0 2H10a1 1 0 1 1 0-2h10.8z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="merge" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M2 4a1 1 0 000 2h3c1.286 0 1.892.28 2.224.553.355.293.554.696.816 1.33l.053.128c.23.562.548 1.337 1.183 1.936.739.695 1.771 1.053 3.224 1.053H15v2a.5.5 0 00.854.354l3-3a.5.5 0 000-.708l-3-3A.5.5 0 0015 7v2h-2.5c-1.118 0-1.595-.267-1.852-.51-.31-.291-.477-.69-.76-1.373-.255-.616-.61-1.463-1.393-2.108C7.688 4.345 6.571 4 5 4H2zm7.924 8.795a1 1 0 10-1.848-.763c-.276.667-.468 1.086-.828 1.394C6.92 13.707 6.315 14 5 14H2a1 1 0 100 2h3c1.608 0 2.74-.361 3.549-1.054.756-.648 1.104-1.492 1.354-2.1l.021-.05z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="messages" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3.667 5L10 9.75 16.333 5H3.667zM17 7l-6.4 4.8a1 1 0 0 1-1.2 0L3 7v8.5a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5V7zM3.5 3h13A2.5 2.5 0 0 1 19 5.5v10a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 1 15.5v-10A2.5 2.5 0 0 1 3.5 3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="meter" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.9 17H3.1c-.4 0-.7-.2-.9-.5C1.4 15.2 1 13.6 1 12c0-5 4-9 9-9s9 4 9 9c0 1.6-.4 3.2-1.2 4.5-.2.3-.5.5-.9.5zM3.7 15h12.6c.4-.9.7-1.9.7-3 0-3.9-3.1-7-7-7s-7 3.1-7 7c0 1.1.2 2.1.7 3z">
                </path>
                <path
                    d="M9.6 15.9c-.5-.2-.7-.8-.5-1.3l2.7-5.4c.2-.5.8-.7 1.3-.5.5.2.7.8.5 1.3l-2.7 5.4c-.2.5-.8.7-1.3.5zm4.6-7.1c-.3 0-.5-.1-.7-.3-.4-.4-.4-1 0-1.4l.7-.7c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-.7.7c-.1.2-.4.3-.7.3zm-8.4 0c-.3 0-.5-.1-.7-.3l-.8-.7c-.3-.4-.3-1.1 0-1.5.4-.4 1-.4 1.4 0l.8.7c.4.4.4 1 0 1.4-.2.3-.5.4-.7.4zM4 13H3c-.6 0-1-.4-1-1s.4-1 1-1h1c.6 0 1 .4 1 1s-.4 1-1 1zm13 0h-1c-.6 0-1-.4-1-1s.4-1 1-1h1c.6 0 1 .4 1 1s-.4 1-1 1zm-7-6c-.6 0-1-.4-1-1V5c0-.6.4-1 1-1s1 .4 1 1v1c0 .6-.4 1-1 1z">
                </path>
                <path d="M10 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="mobile" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7.31 5h5.38C13.966 5 15 6.019 15 7.276v9.448C15 17.981 13.966 19 12.69 19H7.31C6.034 19 5 17.981 5 16.724V7.276C5 6.019 6.034 5 7.31 5zm.331 2A.651.651 0 0 0 7 7.661v8.678c0 .365.287.661.641.661h4.718a.651.651 0 0 0 .641-.661V7.66A.651.651 0 0 0 12.359 7H7.641zM10 14a1 1 0 1 1 0 2 1 1 0 0 1 0-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="money" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14 13v1.1c-.4.2-.8.5-.9.9h-2.9c.4-.5.7-1.2.7-2H6c.1.8.3 1.5.7 2H3.9c-.1-.4-.5-.8-.9-.9V8H2c-.5 0-1 .5-1 1v7c0 .5.5 1 1 1h13c.5 0 1-.5 1-1v-3h-2zM9.8 10h3.5c.4-.6.7-1.5.7-2.5s-.3-1.9-.8-2.5H9.8c-.5.6-.8 1.5-.8 2.5s.3 1.9.8 2.5z">
                </path>
                <path
                    d="M6 9.1v.9h.9c-.1-.4-.5-.8-.9-.9zM16.1 10h.9v-.9c-.4.1-.8.5-.9.9zM17 5.9V5h-.9c.1.4.5.8.9.9zM6.9 5H6v.9c.4-.1.8-.5.9-.9z">
                </path>
                <path d="M18 3H5c-.6 0-1 .4-1 1v7c0 .6.4 1 1 1h13c.6 0 1-.4 1-1V4c0-.6-.4-1-1-1zM6 9.1V5h11V10H6v-.9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="more-actions" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M2 10c0 1.118.86 2 2 2 1.14 0 2-.882 2-2 0-1.118-.86-2-2-2-1.14 0-2 .882-2 2zm8 2c-1.14 0-2-.882-2-2 0-1.118.86-2 2-2 1.14 0 2 .882 2 2 0 1.118-.86 2-2 2zm6 0c-1.14 0-2-.882-2-2 0-1.118.86-2 2-2 1.14 0 2 .882 2 2 0 1.118-.86 2-2 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--accounting" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.75 21h-9c-.273 0-.531.013-.75.037v.926c.219.024.477.037.75.037h10.5c.273 0 .531-.013.75-.037v-.926a7.208 7.208 0 0 0-.75-.037h-1.5zM18 19h.25c1.8 0 2.75.18 2.75 1.333v2.334C21 23.819 20.05 24 18.25 24H7.75C5.95 24 5 23.82 5 22.667v-2.334C5 19.181 5.95 19 7.75 19H8v-2a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v2zm-8.5-1v1h7v-1h-7zM14 4h-2c-1.333 0-1.333-2 0-2h2c1.333 0 1.333 2 0 2zm9 2H3C1.667 6 1.667 4 3 4h20c1.333 0 1.333 2 0 2zM12 6h2v10h-2V6zm10 7a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM4 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--banking" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18.002 11h4a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zm1 2v7h2v-7h-2zm-8-2h4a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zm1 2v7h2v-7h-2zm-8-2h4a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zm1 2v7h2v-7h-2zm-3.48-4.878l11-6a1 1 0 0 1 .958 0l11 6c.91.496.558 1.878-.478 1.878h-22c-1.036 0-1.389-1.382-.48-1.878zM20.08 8l-7.078-3.86L5.923 8H20.08zm3.922 15a1 1 0 0 1 0 2h-22a1 1 0 0 1 0-2h22z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--dashboard" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7.343 20A8.962 8.962 0 0 0 13 22c2.143 0 4.112-.75 5.657-2H7.343zm-1.766-1.909A.98.98 0 0 1 5.991 18h14.018a.98.98 0 0 1 .414.091 9 9 0 1 0-14.845 0zM13 24C6.925 24 2 19.075 2 13S6.925 2 13 2s11 4.925 11 11-4.925 11-11 11zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6zM7.293 9.707a1 1 0 0 1 1.414-1.414l1 1a1 1 0 0 1-1.414 1.414l-1-1zm11.414 0l-1 1a1 1 0 0 1-1.414-1.414l1-1a1 1 0 0 1 1.414 1.414zM12 7a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0V7zm6 8a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2h-2zM6 15a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2H6zm7 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--home" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 22V9a1 1 0 0 1 2 0v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 1 1 2 0v13h16z"></path>
                <path
                    d="M14 18v5a1 1 0 0 1-2 0v-6a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v6a1 1 0 0 1-2 0v-5h-3zM2.479 10.878a1 1 0 0 1-.958-1.756l11-6a1 1 0 0 1 .958 0l11 6a1 1 0 1 1-.958 1.756L13 5.139 2.479 10.878z">
                </path>
                <path d="M10 15a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--launchpad" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3.873 21.287c-.305.293-.629.783-.782 1.622.839-.153 1.329-.477 1.622-.782l-.84-.84zM2 25a1 1 0 0 1-1-1c0-2.989 1.388-4.312 2.553-4.895a1 1 0 0 1 1.154.188l2 2c.305.305.38.77.187 1.154C6.311 23.612 4.989 25 2 25zm14-13a2 2 0 1 0-.001-4A2 2 0 0 0 16 12">
                </path>
                <path
                    d="M22.44 6.44l-2.88-2.88c1.05-.28 2.19-.47 3.41-.53-.06 1.2-.23 2.33-.53 3.41M8.28 18.86L7.1 17.68c.53-2.1 2.99-10.22 10.36-13.39l4.25 4.25c-2.02 4.64-6.47 8.04-13.43 10.32M24 1C15.08 1 10.18 6.4 7.6 11.09c-.02 0-.03.01-.05.02l-6 3A.989.989 0 0 0 1 15c0 .38.21.72.55.89l3.51 1.76c-.03.1-.04.16-.04.17-.06.32.04.65.27.89l2 2c.19.19.45.29.71.29.1 0 .2-.01.3-.05.02-.01.03-.01.05-.02l1.76 3.52c.17.34.51.55.89.55s.72-.21.89-.55l3-6c.05-.09.08-.2.09-.3C21.64 14.46 25 9.05 25 2c0-.55-.45-1-1-1">
                </path>
                <path d="M12.5 15a1.5 1.5 0 1 0-.001-3 1.5 1.5 0 0 0 .001 3"></path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--payroll" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M19 7a1 1 0 0 1 0-2h3c1.758 0 3 1.304 3 3v12c0 1.696-1.242 3-3 3H4c-1.758 0-3-1.304-3-3V8c0-1.696 1.242-3 3-3h3a1 1 0 1 1 0 2H4c-.631 0-1 .387-1 1v12c0 .613.369 1 1 1h18c.631 0 1-.387 1-1V8c0-.613-.369-1-1-1h-3zm1 7a1 1 0 0 1 0 2h-6a1 1 0 0 1 0-2h6zM8 18a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3-13h4a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm0 2v2h4V5h-4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--proservices" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M16.229 5.161a.87.87 0 0 0-.458 1.678 2.653 2.653 0 0 1 1.932 2.57 2.653 2.653 0 0 1-1.93 2.569.87.87 0 1 0 .46 1.677 4.392 4.392 0 0 0 3.21-4.246 4.392 4.392 0 0 0-3.214-4.248zm-6.25-.03c-2.414 0-4.349 1.98-4.349 4.398 0 2.418 1.935 4.4 4.348 4.4s4.348-1.982 4.348-4.4c0-2.417-1.935-4.399-4.348-4.399zm-2.61 4.398c0-1.48 1.18-2.66 2.61-2.66 1.428 0 2.608 1.18 2.608 2.66 0 1.481-1.18 2.66-2.609 2.66S7.37 11.01 7.37 9.53zm10.805 6.2a.87.87 0 0 1 1.097-.555c1.982.649 3.13 2.11 3.77 3.34a8.946 8.946 0 0 1 .776 2.133 4.966 4.966 0 0 1 .038.195l.002.013.001.005v.003L23 21l.859-.136A.87.87 0 0 1 23 21.869h-2.26a.87.87 0 0 1 0-1.739h1.115a7.091 7.091 0 0 0-.358-.814c-.516-.992-1.368-2.031-2.768-2.49a.87.87 0 0 1-.555-1.097zm-3.662 3.365c.333.356.616.713.849 1.036H4.552c.233-.323.516-.68.849-1.036 1.085-1.162 2.61-2.224 4.555-2.224 1.945 0 3.47 1.062 4.556 2.224zm3.185 1.53l-.784.376.785-.375a.87.87 0 0 1-.785 1.245H3a.87.87 0 0 1-.785-1.245L3 21l-.784-.375v-.003l.003-.005.008-.015a11.14 11.14 0 0 1 .482-.846c.316-.503.79-1.175 1.421-1.85 1.25-1.338 3.204-2.776 5.826-2.776 2.623 0 4.576 1.438 5.827 2.776a12.48 12.48 0 0 1 1.783 2.464 7.456 7.456 0 0 1 .12.232l.008.015.002.005v.002h.001z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--purchases" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.395 15.007h11.793c.413 0 .777-.29.896-.712l2.045-7.288H7.646l.749 8zm-1.18-10H23.13c1.033 0 1.871.896 1.871 2 0 .195-.027.389-.079.575l-2.045 7.287c-.356 1.27-1.449 2.138-2.688 2.138H7.548c-.48 0-.883-.389-.93-.9l-.936-10a1.093 1.093 0 0 1-.003-.032L4.227 4H1.88C1.394 4 1 3.552 1 3s.394-1 .88-1h2.64c.047 0 .092.004.137.012a.934.934 0 0 1 .74.399l1.819 2.596zM10 24a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm9 2a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--reports" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3 13h4a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1zm1 8h2v-6H4v6zM19 3h4a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm1 18h2V5h-2v16zM11 8h4a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1zm1 13h2V10h-2v11z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--sales" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M23 9.003V7c0-.552-.471-1-1.053-1H4.053C3.47 6 3 6.448 3 7v2h19.913c.03 0 .058.001.087.003zm0 1.994a1.103 1.103 0 0 1-.087.003H3v8c0 .552.471 1 1.053 1h17.894C22.53 20 23 19.552 23 19v-8.003zM4.13 4h17.74C23.598 4 25 5.343 25 7v12c0 1.657-1.402 3-3.13 3H4.13C2.402 22 1 20.657 1 19V7c0-1.657 1.402-3 3.13-3zm7.261 11h8.435a1 1 0 0 1 0 2h-8.435a1 1 0 0 1 0-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="nav--taxes" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17 1a1 1 0 01.707.293l5 5A1 1 0 0123 7v15.5a2.5 2.5 0 01-2.5 2.5h-15A2.5 2.5 0 013 22.5v-19A2.5 2.5 0 015.5 1H17zm-1 2H5.5a.5.5 0 00-.5.5v19a.5.5 0 00.5.5h15a.5.5 0 00.5-.5V8h-4a1 1 0 01-1-1V3zm2 1.414V6h1.586L18 4.414z">
                </path>
                <path d="M8.293 17.293a1 1 0 101.414 1.414l8-8a1 1 0 00-1.414-1.414l-8 8z"></path>
                <path fill-rule="evenodd"
                    d="M10 13a3 3 0 110-6 3 3 0 010 6zm1-3a1 1 0 11-2 0 1 1 0 012 0zM13 18a3 3 0 106 0 3 3 0 00-6 0zm3 1a1 1 0 100-2 1 1 0 000 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="navigation" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M2 11a1 1 0 1 1 0-2h16a1 1 0 0 1 0 2H2zm0-5a1 1 0 1 1 0-2h16a1 1 0 0 1 0 2H2zm0 10a1 1 0 0 1 0-2h16a1 1 0 0 1 0 2H2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="note" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M4 1h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm1 2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H5zm2 2h6a1 1 0 0 1 0 2H7a1 1 0 1 1 0-2zm0 4h6a1 1 0 0 1 0 2H7a1 1 0 1 1 0-2zm0 4h3a1 1 0 1 1 0 2H7a1 1 0 0 1 0-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="notification-danger" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M7.1 1h5.8c.5 0 1 .2 1.4.6l4.1 4.1c.4.4.6.9.6 1.4v5.8c0 .5-.2 1-.6 1.4l-4.1 4.1c-.4.4-.9.6-1.4.6H7.1c-.5 0-1-.2-1.4-.6l-4.1-4.1c-.4-.4-.6-.9-.6-1.4V7.1c0-.5.2-1 .6-1.4l4.1-4.1c.4-.4.9-.6 1.4-.6zM9 6a1 1 0 112 0v5a1 1 0 11-2 0V6zm1 7a1 1 0 100 2 1 1 0 000-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="notification-info" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M10 19a9 9 0 110-18 9 9 0 010 18zM9 6a1 1 0 112 0 1 1 0 01-2 0zm0 2a1 1 0 000 2v3a1 1 0 100 2h2a1 1 0 100-2V9a1 1 0 00-1-1H9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="notification-success" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M10 19a9 9 0 100-18 9 9 0 000 18zm-2-7.414l5.293-5.293a1 1 0 111.414 1.414l-6 6a1 1 0 01-1.414 0l-2-2a1 1 0 111.414-1.414L8 11.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="notification-warning" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M7.916 3.222C8.369 2.453 9.153 2 10 2c.848 0 1.632.453 2.085 1.222l6.594 11.196c.426.758.428 1.689.006 2.449-.424.765-1.147 1.122-2.084 1.133H3.391c-.928-.01-1.65-.368-2.075-1.133a2.51 2.51 0 010-2.436l6.6-11.21zM9 7a1 1 0 112 0v5a1 1 0 11-2 0V7zm1 7a1 1 0 100 2 1 1 0 000-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="open-menu" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13.84 7.772c.348-.426.175-.772-.376-.772H6.559c-.556 0-.727.342-.377.772l3.2 3.928c.35.426.91.43 1.26 0l3.2-3.928h-.001z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="open-new-window" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15 12a1 1 0 0 0-1 1v.5a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5H7a1 1 0 1 0 0-2h-.5A2.5 2.5 0 0 0 4 6.5v7A2.5 2.5 0 0 0 6.5 16h7a2.5 2.5 0 0 0 2.5-2.5V13a1 1 0 0 0-1-1Z">
                </path>
                <path
                    d="M9.32 10.657c-.39-.39-.43-.985-.087-1.327L12.563 6h-1.828a1 1 0 1 1 0-2h4.242a1 1 0 0 1 1 1v4.243a1 1 0 1 1-2 0V7.414l-3.33 3.33c-.342.342-.936.303-1.327-.087Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="phone" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14.4 18C8.3 18 2 12.1 2 6.4c0-2.1 3-3.8 3.9-4.3.4-.2 1-.1 1.3.3l2.5 3.3c.3.3.3.8 0 1.2L8.2 9c.5.7 2.1 2.3 2.8 2.8l2.1-1.4c.4-.2.8-.2 1.2 0l3.3 2.5c.4.3.5.8.3 1.3-2 3.8-3.1 3.8-3.5 3.8zM6.1 4.3C5 5 4 5.9 4 6.4c0 4.5 5.3 9.5 10.3 9.6.3-.3.9-1.1 1.5-2.1l-2-1.5-2 1.3c-.2.1-.4.2-.6.2-1.4 0-5.1-3.7-5.1-5.1 0-.2.1-.4.2-.6l1.3-2-1.5-1.9z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="pie-chart" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M9 19c-4.4 0-8-3.6-8-8s3.6-8 8-8c.6 0 1 .4 1 1v6h6c.6 0 1 .4 1 1 0 4.4-3.6 8-8 8zM8 5.1C5.2 5.6 3 8 3 11c0 3.3 2.7 6 6 6 3 0 5.4-2.2 5.9-5H9c-.6 0-1-.4-1-1V5.1z">
                </path>
                <path
                    d="M18 9h-6c-.6 0-1-.4-1-1V2c0-.6.4-1 1-1 3.9 0 7 3.1 7 7 0 .6-.4 1-1 1zm-5-2h3.9C16.5 5 15 3.5 13 3.1V7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="piggy-bank" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15 19h-4c-.6 0-1-.4-1-1H9c0 .6-.4 1-1 1H4c-.6 0-1-.4-1-1v-2.4c-1.2-1.2-2-2.3-2-4.6 0-4.2 3.7-6.7 10-6.8.1-.1.2-.2.3-.4.3-.4 1.1-1.4 2.2-.8.5.3 1 1.1 1.9 3.3l.1.3c.4 1.1.8 1.4 1.5 1.4h1c.6 0 1 .4 1 1v4c0 .6-.4 1-1 1h-.3c-.3.5-.8 1.3-1.7 2v2c0 .6-.4 1-1 1zm-3-2h2v-1.5c0-.3.2-.6.4-.8 1.3-.9 1.6-1.9 1.6-1.9.1-.4.5-.7 1-.7V10c-2.2 0-3-1.8-3.3-2.5l-.1-.3c-.4-.9-.7-1.5-.9-1.9-.3.4-.8.9-1.6.9C8.7 6.3 3 6.7 3 11c0 1.7.5 2.3 1.7 3.4.2.2.3.5.3.8V17h2c0-.3.1-.6.3-.7.2-.3.5-.4.8-.3.9.1 1.8 0 2.8-.1.3 0 .6.1.8.2.2.2.3.5.3.8v.1z">
                </path>
                <path
                    d="M5.6 4.3c-.2 0-.3 0-.5-.1-.5-.3-.7-.9-.4-1.4.5-1 1.5-1.6 2.6-1.8 1.1-.2 2.2.2 3 1 .4.4.4 1 0 1.4-.4.4-1 .4-1.4 0C8.5 3.1 8 3 7.6 3c-.5.1-.9.4-1.1.8-.2.3-.6.5-.9.5zM12 10a1 1 0 100-2 1 1 0 000 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="plaid" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.344 2 3.392 3.284l-1.364 4.93L3.734 9.95 2 11.656l1.284 4.952 4.93 1.364 1.735-1.707L11.656 18l4.952-1.284 1.364-4.93-1.706-1.735L18 8.344l-1.284-4.952-4.931-1.364-1.734 1.706L8.344 2ZM5.305 4.233l2.609-.677 1.14 1.16-1.663 1.636-2.086-2.12Zm5.726.498 1.16-1.14 2.597.718-2.12 2.085-1.637-1.663ZM3.591 7.81l.718-2.597 2.085 2.12L4.73 8.968l-1.14-1.16Zm10.057-.42 2.12-2.085.676 2.609-1.159 1.14-1.637-1.663Zm-5.277-.042 1.664-1.637 1.636 1.664-1.663 1.637L8.37 7.348Zm-2.66 2.617 1.664-1.637 1.637 1.664-1.664 1.637-1.637-1.664Zm5.277.043 1.664-1.637 1.636 1.664-1.663 1.636-1.636-1.663Zm-7.432 2.078 1.159-1.14 1.636 1.664-2.119 2.084-.676-2.608Zm4.772.539 1.664-1.637 1.636 1.664-1.663 1.637-1.637-1.664Zm5.277.043 1.664-1.636 1.14 1.159-.718 2.596-2.086-2.119Zm-8.393 3.023 2.12-2.086 1.637 1.664-1.16 1.14-2.597-.718Zm5.734-.406 1.663-1.637 2.085 2.12-2.608.676-1.14-1.16Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="plant" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18.5 2C18.4 1.9 15.2 0.3 12.7 1.7C11.9 2.1 11.4 2.8 11 3.5V2C11 1.4 10.6 1 10 1C9.4 1 9 1.4 9 2V7.4C8.8 7.1 8.5 6.8 8.1 6.6C6.2 5.5 3.8 6.7 3.5 6.8C3.2 7 3 7.4 3 7.8C3 8.1 3.2 10.7 5.1 11.9C5.7 12.3 6.4 12.4 7 12.4C7.8 12.4 8.5 12.2 9 12V16.2C7.7 16.3 6.5 16.7 5.5 17.3C5 17.6 4.9 18.2 5.2 18.7C5.4 19 6 19.2 6.5 18.9C8.4 17.8 11.6 17.8 13.5 18.9C13.6 19 13.8 19 14 19C14.3 19 14.7 18.8 14.9 18.5C15.2 18 15 17.4 14.6 17.1C13.6 16.5 12.4 16.2 11.1 16V7.9C11.7 8.2 12.9 8.6 14.2 8.6C15 8.6 15.8 8.4 16.5 8C19 6.6 19.1 3 19.1 2.8C19.1 2.5 18.9 2.2 18.5 2ZM6.1 10.1C5.5 9.8 5.2 9 5.1 8.4C5.7 8.2 6.5 8.1 7.1 8.4C7.7 8.7 8 9.5 8.1 10.1C7.5 10.3 6.7 10.4 6.1 10.1ZM15.4 6.3C14.4 6.9 13 6.6 12.1 6.2C12.3 5.3 12.8 4 13.7 3.4C14.7 2.8 16.1 3.1 17 3.5C16.9 4.3 16.5 5.7 15.4 6.3Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="play" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M15.235 8.805c.477.276.764.736.765 1.23.002.494-.283.958-.762 1.238l-8.5 5.468a2.017 2.017 0 01-1.788.094c-.586-.257-.95-.767-.95-1.33V4.496c0-.563.364-1.072.95-1.329a2.01 2.01 0 011.787.093l8.498 5.546z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="preview" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10.207 6c-4.047 0-8 3.164-8 5 0 1.836 3.953 5 8 5 4.047 0 8-3.164 8-5 0-1.836-3.953-5-8-5Zm0 8c-3.12 0-5.61-2.236-5.975-3 .364-.764 2.854-3 5.975-3 3.121 0 5.61 2.236 5.975 3-.364.764-2.854 3-5.975 3Z">
                </path>
                <path
                    d="M10.207 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM10.207 5a1 1 0 0 0 1-1V3a1 1 0 1 0-2 0v1a1 1 0 0 0 1 1ZM16.707 6.707a.997.997 0 0 0 .707-.293l.707-.707a.999.999 0 1 0-1.414-1.414L16 5a.999.999 0 0 0 .707 1.707ZM3 6.414a.997.997 0 0 0 1.414 0 .999.999 0 0 0 0-1.414l-.707-.707a.999.999 0 1 0-1.414 1.414L3 6.414Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="print" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M4 16h-.4C2.176 16 1 14.889 1 13.489V9.51C1 8.111 2.176 7 3.6 7H4V2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v5h.4C17.824 7 19 8.111 19 9.511v3.978c0 1.4-1.176 2.511-2.6 2.511H16v2a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-2zm0-2v-2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v2h.4c.344 0 .6-.242.6-.511V9.51c0-.269-.256-.511-.6-.511H3.6c-.344 0-.6.242-.6.511v3.978c0 .269.256.511.6.511H4zm2-7h8V3H6v4zm0 6v4h8v-4H6z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="product" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.3 4.5l-5-2.2c-.8-.4-1.8-.4-2.6 0l-5 2.2C2.7 4.9 2 5.9 2 7v5.7c0 1 .6 2 1.6 2.4l5 2.5c.9.4 2 .4 2.9 0l5-2.5c1-.5 1.6-1.4 1.6-2.4V7c-.1-1.1-.8-2.1-1.8-2.5zm-6.7-.6c.3-.1.6-.1.9 0l5 2.2h.1l-1.5.7s-.1 0-.1-.1L8.6 4.4l1-.5zM9 15.8l-4.5-2.2c-.3-.2-.5-.5-.5-.9V8l4.6 2.2c.1.1.3.1.4.2v5.4zm.5-7.2l-5-2.4h.1l1.7-.8L11.9 8l-1.4.7c-.3.1-.7.1-1-.1zm6.5 4.1c0 .3-.2.7-.5.8L11 15.8v-5.3c.1 0 .3-.1.4-.2L16 8v4.7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="product-add" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.3 4.4l-5-2.2c-.8-.4-1.8-.4-2.6 0l-5 2.2C2.7 4.9 2 5.8 2 6.9v5.7c0 1 .6 1.9 1.6 2.4l5.9 2.9c.5.2 1.1.1 1.4-.4.1-.2.1-.4.1-.6V10.3c.1 0 .3-.1.4-.2L16 8v2.7c0 .5.4.9 1 .9s1-.4 1-.9V6.9c0-1.1-.7-2-1.7-2.5zM9 15.6l-4.5-2.2c-.3-.2-.5-.5-.5-.8V8l4.6 2.2c.1.1.3.1.4.2v5.2zm2.9-7.7l-1.4.7c-.3.1-.6.1-.9 0l-5-2.4h.1l1.7-.7 5.5 2.4zm2.2-1.1c-.1 0-.1 0 0 0L8.6 4.3l1-.4c.3-.1.6-.1.9 0l5 2.2h.1l-1.5.7z">
                </path>
                <path
                    d="M15 12c.6 0 1 .4 1 1v1h1c.6 0 1 .4 1 1s-.4 1-1 1h-1v1c0 .6-.4 1-1 1s-1-.4-1-1v-1h-1c-.6 0-1-.4-1-1s.4-1 1-1h1v-1c0-.6.4-1 1-1z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="product-remove" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.3 4.4l-5-2.2c-.8-.4-1.8-.4-2.6 0l-5 2.2C2.7 4.9 2 5.8 2 6.9v5.7c0 1 .6 1.9 1.6 2.4l5.9 2.9c.5.2 1.1.1 1.4-.4.1-.2.1-.4.1-.6V10.3c.1 0 .3-.1.4-.2L16 8v2.7c0 .5.4.9 1 .9s1-.4 1-.9V6.9c0-1.1-.7-2-1.7-2.5zM9 15.6l-4.5-2.2c-.3-.2-.5-.5-.5-.8V8l4.6 2.2c.1.1.3.1.4.2v5.2zm2.9-7.7l-1.4.7c-.3.1-.6.1-.9 0l-5-2.4h.1l1.7-.7 5.5 2.4zm2.2-1.1c-.1 0-.1 0 0 0L8.6 4.3l1-.4c.3-.1.6-.1.9 0l5 2.2h.1l-1.5.7z">
                </path>
                <path d="M13 14c-.6 0-1 .4-1 1s.4 1 1 1h4c.6 0 1-.4 1-1s-.4-1-1-1h-4z"></path>
            </symbol>
            <symbol viewBox="0 0 26 26" id="profile--large" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 24C6.925 24 2 19.075 2 13S6.925 2 13 2s11 4.925 11 11-4.925 11-11 11zm0-2a9 9 0 1 0 0-18 9 9 0 0 0 0 18z">
                </path>
                <path
                    d="M13 14c-2.122 0-4-1.878-4-4s1.878-4 4-4 4 1.878 4 4-1.878 4-4 4zm0-2c1.017 0 2-.983 2-2s-.983-2-2-2-2 .983-2 2 .983 2 2 2zM6.894 20.447l-1.788-.894C6.615 16.535 9.3 15 13 15s6.385 1.535 7.894 4.553l-1.788.894C17.948 18.132 15.967 17 13 17s-4.948 1.132-6.106 3.447z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="receipt" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14 2.586l1.293-1.293C15.923.663 17 1.109 17 2v16c0 .89-1.077 1.337-1.707.707L14 17.414l-1.293 1.293a1 1 0 0 1-1.414 0L10 17.414l-1.293 1.293a1 1 0 0 1-1.414 0L6 17.414l-1.293 1.293C4.077 19.337 3 18.891 3 18V2c0-.89 1.077-1.337 1.707-.707L6 2.586l1.293-1.293a1 1 0 0 1 1.414 0L10 2.586l1.293-1.293a1 1 0 0 1 1.414 0L14 2.586zm1 13V4.414l-.293.293a1 1 0 0 1-1.414 0L12 3.414l-1.293 1.293a1 1 0 0 1-1.414 0L8 3.414 6.707 4.707a1 1 0 0 1-1.414 0L5 4.414v11.172l.293-.293a1 1 0 0 1 1.414 0L8 16.586l1.293-1.293a1 1 0 0 1 1.414 0L12 16.586l1.293-1.293a1 1 0 0 1 1.414 0l.293.293zM13 12a1 1 0 0 1 0 2H7a1 1 0 0 1 0-2h6zm0-3a1 1 0 0 1 0 2H7a1 1 0 0 1 0-2h6zm-3-3a1 1 0 1 1 0 2H7a1 1 0 1 1 0-2h3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="refresh" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.346 7H7.5a1 1 0 1 1 0 2H3a1 1 0 0 1-1-1V3.5a1 1 0 1 1 2 0v1.989c.157-.191.389-.473.48-.581C6.137 2.933 7.741 2 10.5 2c3.03 0 5.507 1.524 7.348 4.47a1 1 0 1 1-1.696 1.06C14.66 5.142 12.803 4 10.5 4c-2.09 0-3.178.633-4.49 2.194-.12.143-.538.655-.62.752L5.347 7zm9.308 6H12.5a1 1 0 0 1 0-2H17a1 1 0 0 1 1 1v4.5a1 1 0 0 1-2 0v-1.989c-.157.192-.389.474-.48.581C13.863 17.068 12.259 18 9.5 18c-3.03 0-5.507-1.524-7.348-4.47a1 1 0 1 1 1.696-1.06C5.34 14.858 7.197 16 9.5 16c2.09 0 3.178-.633 4.49-2.194.12-.143.539-.655.62-.752l.044-.054z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="reminder" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M2 13c.773 0 1-.227 1-1V8c0-3.645 3.355-7 7-7s7 3.355 7 7v4c0 .773.227 1 1 1 1.333 0 1.333 2 0 2H2c-1.333 0-1.333-2 0-2zm13.123 0A3.878 3.878 0 0 1 15 12V8c0-2.54-2.46-5-5-5S5 5.46 5 8v4c0 .362-.042.697-.123 1h10.246zM10 19c-1.997 0-2.995-1.197-2.995-2.044C7.005 16.11 6.749 16 10 16c3.25 0 2.995.11 2.995.956 0 .847-.998 2.044-2.995 2.044z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="review" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M9 16C5.68629 16 3 13.3137 3 10C3 6.68629 5.68629 4 9 4C12.3137 4 15 6.68629 15 10C15 13.3137 12.3137 16 9 16ZM16.748 8C16.8318 8.32577 16.8957 8.65956 16.9381 9H18C18.5523 9 19 9.44772 19 10C19 10.5523 18.5523 11 18 11H16.9381C16.8957 11.3404 16.8318 11.6742 16.748 12H18C18.5523 12 19 12.4477 19 13C19 13.5523 18.5523 14 18 14H16C15.9768 14 15.9539 13.9992 15.9311 13.9977C14.5482 16.3902 11.9621 18 9 18C7.38639 18 5.88437 17.5223 4.62764 16.7005L2.74352 18.5847C2.35299 18.9752 1.71983 18.9752 1.3293 18.5847C0.938779 18.1941 0.938779 17.561 1.3293 17.1705L3.09852 15.4012C1.79524 13.978 1 12.0819 1 10C1 5.58172 4.58172 2 9 2C11.9621 2 14.5482 3.60984 15.9311 6.00234C15.9539 6.00079 15.9768 6 16 6H18C18.5523 6 19 6.44772 19 7C19 7.55228 18.5523 8 18 8H16.748ZM8 6C7.44772 6 7 6.44772 7 7C7 7.55228 7.44772 8 8 8H11C11.5523 8 12 7.55228 12 7C12 6.44772 11.5523 6 11 6H8ZM7 9C6.44772 9 6 9.44772 6 10C6 10.5523 6.44772 11 7 11H12C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9H7ZM7 13C7 12.4477 7.44772 12 8 12H11C11.5523 12 12 12.4477 12 13C12 13.5523 11.5523 14 11 14H8C7.44772 14 7 13.5523 7 13Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="robot" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M8.05071 11.5C8.05071 12.3284 7.37914 13 6.55071 13C5.72228 13 5.05071 12.3284 5.05071 11.5C5.05071 10.6716 5.72228 10 6.55071 10C7.37914 10 8.05071 10.6716 8.05071 11.5Z">
                </path>
                <path
                    d="M13.5507 13C14.3791 13 15.0507 12.3284 15.0507 11.5C15.0507 10.6716 14.3791 10 13.5507 10C12.7223 10 12.0507 10.6716 12.0507 11.5C12.0507 12.3284 12.7223 13 13.5507 13Z">
                </path>
                <path
                    d="M7.3436 13.7929C7.71856 13.4179 8.31721 13.403 8.71 13.7481C8.72646 13.7587 8.77396 13.7873 8.8596 13.8215C9.04122 13.8942 9.41342 14 10.0507 14C10.688 14 11.0602 13.8942 11.2418 13.8215C11.3275 13.7873 11.375 13.7587 11.3914 13.7481C11.7842 13.403 12.3828 13.4179 12.7578 13.7929C13.1483 14.1834 13.1483 14.8166 12.7578 15.2071L12.7174 15.2456C12.7015 15.26 12.683 15.2761 12.662 15.2934C12.6199 15.3281 12.5675 15.3677 12.5038 15.4102C12.3762 15.4953 12.2054 15.5902 11.9846 15.6785C11.5412 15.8558 10.9134 16 10.0507 16C9.18798 16 8.5602 15.8558 8.11682 15.6785C7.89602 15.5902 7.72524 15.4953 7.59757 15.4102C7.53392 15.3677 7.48153 15.3281 7.43942 15.2934C7.41838 15.2761 7.39996 15.26 7.38402 15.2456L7.3436 15.2071C6.95308 14.8166 6.95308 14.1834 7.3436 13.7929Z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M11.7831 4C11.9533 3.70583 12.0507 3.36429 12.0507 3C12.0507 1.89543 11.1553 1 10.0507 1C8.94613 1 8.05071 1.89543 8.05071 3C8.05071 3.36429 8.14811 3.70583 8.31828 4H4.05632C2.95175 4 2 4.89543 2 6V9.44444L1.92523 9.53043C0.676011 10.967 0.612403 13.085 1.77315 14.594L2 14.8889V15.2389C2 16.8418 3.19355 18.2193 4.76744 18.5229C8.11437 19.1683 11.776 19.1683 15.1229 18.5229C16.6968 18.2193 18 16.81 18 15.2071V14.8571L18.2268 14.5622C19.3876 13.0532 19.3239 10.9352 18.0747 9.49862L18 9.41263V5.96819C18 4.86362 17.1552 4 16.0507 4H11.7831ZM4.05069 15.2389V14.2086L3.41472 13.3746C2.83434 12.6201 2.86615 11.5611 3.49075 10.8428L4.05069 10.1924V6L16.0507 6V10.1924L16.6162 10.8428C17.2408 11.5611 17.2727 12.6201 16.6923 13.3746L16.0507 14.2086V15.2389C16.0507 15.8833 15.5935 16.437 14.9608 16.559C11.8641 17.1563 8.24292 17.1563 5.14617 16.559C4.51348 16.437 4.05069 15.8833 4.05069 15.2389Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="scan" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17 11h-1V4c0-1.1-.9-2-2-2H6c-1.1 0-2 .9-2 2v7H3c-.6 0-1 .4-1 1s.4 1 1 1h14c.6 0 1-.4 1-1s-.4-1-1-1zm-3 0H6V5c0-.6.4-1 1-1h6c.6 0 1 .4 1 1v6zM4 16v-2h2v1c0 .6.4 1 1 1h6c.6 0 1-.4 1-1v-1h2v2c0 1.1-.9 2-2 2H6c-1.1 0-2-.9-2-2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="search" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15.32 13.906l3.387 3.387a1 1 0 0 1-1.414 1.414l-3.387-3.387a8 8 0 1 1 1.414-1.414zM9 15A6 6 0 1 0 9 3a6 6 0 0 0 0 12z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="secure" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5 8V6c0-2.7 2.3-5 5-5s5 2.3 5 5v2h.5a2.5 2.5 0 0 1 2.5 2.5v6a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 2 16.5v-6A2.5 2.5 0 0 1 4.5 8H5zm1 2H4.5a.5.5 0 0 0-.5.5v6a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 .5-.5v-6a.5.5 0 0 0-.5-.5H6zm1-2h6V6c0-1.595-1.405-3-3-3S7 4.405 7 6v2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="send" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17.654 1.061a1 1 0 0 1 1.284 1.284l-5.492 15.98c-.302.877-1.53.907-1.874.046L8.73 11.27 1.629 8.43c-.861-.345-.83-1.573.046-1.875l15.98-5.493zm-6.98 9.68l1.755 4.39 3.219-9.365-4.975 4.975zM9.258 9.327l4.975-4.975L4.87 7.571l4.39 1.756z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="settings" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.303 7.503a.193.193 0 0 0 .119.042h.123a2.455 2.455 0 1 1 0 4.91h-.061a.2.2 0 0 0-.183.12c-.037.085-.021.173.028.223l.043.044a2.455 2.455 0 1 1-3.472 3.472c-.094-.093-.181-.109-.266-.071a.199.199 0 0 0-.121.179v.123a2.455 2.455 0 1 1-4.91 0c-.001-.124-.053-.196-.189-.248a.197.197 0 0 0-.212.032l-.044.043A2.455 2.455 0 1 1 3.686 12.9c.093-.094.109-.181.071-.266a.199.199 0 0 0-.179-.121h-.123a2.455 2.455 0 0 1 0-4.91c.124-.001.196-.053.248-.189a.197.197 0 0 0-.032-.212l-.043-.044A2.455 2.455 0 1 1 7.1 3.686c.094.093.181.109.256.076l.147-.065a.193.193 0 0 0 .042-.119v-.123a2.455 2.455 0 1 1 4.91 0v.061c0 .08.047.152.13.187a.197.197 0 0 0 .213-.032l.044-.043A2.455 2.455 0 1 1 16.314 7.1c-.093.094-.109.181-.076.256l.065.147zm.177 2.952h.065a.455.455 0 1 0 0-.91h-.127a2.2 2.2 0 0 1-2.014-1.333l-.08-.189v-.085a2.206 2.206 0 0 1 .533-2.209l.044-.044a.455.455 0 1 0-.645-.643l-.051.051a2.196 2.196 0 0 1-2.417.444 2.201 2.201 0 0 1-1.333-2.017v-.065a.455.455 0 0 0-.91 0v.127a2.2 2.2 0 0 1-1.333 2.014l-.189.08h-.085a2.206 2.206 0 0 1-2.209-.533L5.685 5.1a.455.455 0 1 0-.643.645l.051.051c.629.643.803 1.604.464 2.368a2.207 2.207 0 0 1-2.037 1.44h-.065a.455.455 0 0 0 0 .91h.127a2.196 2.196 0 0 1 2.01 1.323 2.204 2.204 0 0 1-.449 2.435l-.044.044a.455.455 0 1 0 .645.643l.051-.051c.643-.629 1.604-.803 2.368-.464a2.207 2.207 0 0 1 1.44 2.037v.065a.455.455 0 1 0 .91 0v-.127a2.196 2.196 0 0 1 1.323-2.01 2.204 2.204 0 0 1 2.435.449l.044.044a.455.455 0 1 0 .643-.645l-.051-.051a2.2 2.2 0 0 1-.442-2.422 2.201 2.201 0 0 1 2.015-1.328zM10 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-2a1 1 0 1 0 0-2 1 1 0 0 0 0 2z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="shield" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19c-.2 0-.3 0-.5-.1C9.2 18.7 2 14.5 2 6c0-.6.4-1 1-1 .7 0 4.3-1.8 6.3-3.7.4-.4 1-.4 1.4 0 2 2 5.6 3.7 6.3 3.7.5 0 1 .5 1 1 0 9.5-7.3 12.8-7.6 12.9-.1.1-.3.1-.4.1zM4 6.8c.4 5.7 4.6 9.1 6 10.1 1.4-.8 5.6-3.6 5.9-10.1-1.6-.5-4.2-2-6-3.4C8.2 4.8 5.6 6.3 4 6.8z">
                </path>
                <path
                    d="M9 13c-.3 0-.5-.1-.7-.3l-2-2c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L9 10.6l3.3-3.3c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-4 4c-.2.2-.4.3-.7.3z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="sort" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M14 15.796l2.342-2.049a1 1 0 1 1 1.317 1.506l-4 3.5a1 1 0 0 1-1.317 0l-4-3.5a1 1 0 1 1 1.317-1.506L12 15.797V10a1 1 0 1 1 2 0v5.796zM6 4.204L3.659 6.253a1 1 0 1 1-1.317-1.506l4-3.5a1 1 0 0 1 1.317 0l4 3.5a1 1 0 0 1-1.317 1.506L8 4.203V10a1 1 0 0 1-2 0V4.204z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="split" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15 14.001v-2a.5.5 0 01.854-.354l3 3a.5.5 0 010 .708l-3 3A.5.5 0 0115 18v-2h-2.5c-2.55 0-3.535-.877-4.41-2.997l-.05-.12C7.425 11.397 6.944 11 5 11H2a1 1 0 110-2h3c1.944 0 2.425-.396 3.04-1.883l.05-.12C8.965 4.877 9.95 4 12.5 4H15v-2a.5.5 0 01.854-.354l3 3a.5.5 0 010 .708l-3 3A.5.5 0 0115 8v-2h-2.5c-1.611 0-1.964.315-2.561 1.76l-.05.123C9.507 8.802 9.083 9.5 8.506 10c.577.5 1 1.2 1.381 2.117l.051.123c.597 1.445.95 1.76 2.561 1.76H15z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="star" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 3.636L8.206 7.229a.817.817 0 0 1-.616.442l-4.013.58 2.903 2.796a.803.803 0 0 1 .236.716L6.03 15.71l3.588-1.865a.827.827 0 0 1 .762 0l3.588 1.865-.685-3.948a.803.803 0 0 1 .236-.716l2.903-2.796-4.013-.58a.817.817 0 0 1-.616-.442L10 3.636zM6.929 6.132l2.337-4.681a.822.822 0 0 1 1.468 0l2.337 4.681 5.228.756c.671.096.938.911.453 1.379l-3.782 3.641.892 5.145c.115.66-.587 1.164-1.187.852L10 15.475l-4.675 2.43c-.6.312-1.302-.192-1.187-.852l.892-5.145-3.782-3.641a.806.806 0 0 1 .453-1.38l5.228-.755z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="stop" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12.9 3L17 7.1v5.8L12.9 17H7.1L3 12.9V7.1L7.1 3h5.8zm0-2H7.1c-.5 0-1 .2-1.4.6L1.6 5.7c-.4.4-.6.9-.6 1.4v5.8c0 .5.2 1 .6 1.4l4.1 4.1c.4.4.9.6 1.4.6h5.8c.5 0 1-.2 1.4-.6l4.1-4.1c.4-.4.6-.9.6-1.4V7.1c0-.5-.2-1-.6-1.4l-4.1-4.1c-.4-.4-.9-.6-1.4-.6z">
                </path>
                <path d="M9 14a1 1 0 112 0 1 1 0 01-2 0zm1-9a1 1 0 00-1 1v5a1 1 0 102 0V6a1 1 0 00-1-1z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="subtract" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19a9 9 0 1 1 0-18 9 9 0 0 1 0 18zm1-10H5.833C5.373 9 5 9.448 5 10s.373 1 .833 1h8.334c.46 0 .833-.448.833-1s-.373-1-.833-1H11zm-1 8c4.067 0 7-2.933 7-7s-2.933-7-7-7-7 2.933-7 7 2.933 7 7 7z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="subtract--simple" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.167 9c.46 0 .833.448.833 1s-.373 1-.833 1H3.833C3.373 11 3 10.552 3 10s.373-1 .833-1h12.334z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="success" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 19a9 9 0 1 1 0-18 9 9 0 0 1 0 18zm0-2a7 7 0 1 0 0-14 7 7 0 0 0 0 14zm-2-5.414l5.293-5.293a1 1 0 0 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L8 11.586z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="tablet" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.5 1h9A2.5 2.5 0 0 1 17 3.5v13a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 3 16.5v-13A2.5 2.5 0 0 1 5.5 1zm0 2a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-13a.5.5 0 0 0-.5-.5h-9zM10 16a2 2 0 1 1 0-4 2 2 0 0 1 0 4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="tag" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17.646 11.768l-5.878 5.878a2.5 2.5 0 0 1-3.536 0l-6.94-6.939A1 1 0 0 1 1 10V2a1 1 0 0 1 1-1h8a1 1 0 0 1 .707.293l6.94 6.94a2.5 2.5 0 0 1 0 3.535zM3 9.586l6.646 6.646a.5.5 0 0 0 .708 0l5.878-5.878a.5.5 0 0 0 0-.708L9.586 3H3v6.586zM6 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="tasks" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M9.19 5.92 7.52 7.59l-.27-.27a.996.996 0 1 0-1.41 1.41l.98.98c.2.2.45.29.71.29.26 0 .51-.1.71-.29l2.38-2.38a.996.996 0 1 0-1.41-1.41h-.02ZM14 7h-1c-.55 0-1 .45-1 1s.45 1 1 1h1c.55 0 1-.45 1-1s-.45-1-1-1ZM9.19 10.92l-1.67 1.67-.27-.27a.996.996 0 1 0-1.41 1.41l.98.98c.2.2.45.29.71.29.26 0 .51-.1.71-.29l2.38-2.38a.996.996 0 1 0-1.41-1.41h-.02ZM14 12h-1c-.55 0-1 .45-1 1s.45 1 1 1h1c.55 0 1-.45 1-1s-.45-1-1-1Z">
                </path>
                <path
                    d="M15.5 1h-11A2.5 2.5 0 0 0 2 3.5v13A2.5 2.5 0 0 0 4.5 19h11a2.5 2.5 0 0 0 2.5-2.5v-13A2.5 2.5 0 0 0 15.5 1Zm.5 15.5c0 .28-.22.5-.5.5h-11c-.28 0-.5-.22-.5-.5v-13c0-.28.22-.5.5-.5h11c.28 0 .5.22.5.5v13Z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="taxes" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M4 1h12a2 2 0 012 2v14a2 2 0 01-2 2H4a2 2 0 01-2-2V3a2 2 0 012-2zm1 2a1 1 0 00-1 1v12a1 1 0 001 1h10a1 1 0 001-1V4a1 1 0 00-1-1H5z">
                </path>
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M13.707 6.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414l6-6a1 1 0 011.414 0z"></path>
                <path d="M9 6.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM14 13.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="time" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <path
                        d="M9 18A9 9 0 1 1 9 0a9 9 0 0 1 0 18zm0-2A7 7 0 1 0 9 2a7 7 0 0 0 0 14zm3.215-4.616a1.023 1.023 0 1 1-1.52 1.368L8.24 10.025a1.023 1.023 0 0 1-.263-.684V3.886a1.023 1.023 0 1 1 2.046 0v5.062l2.192 2.436z"
                        id="fba"></path>
                </defs>
                <use xlink:href="#fba" transform="translate(1 1)"></use>
            </symbol>
            <symbol viewBox="0 0 20 20" id="transaction" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M13 10H7c-.6 0-1-.4-1-1s.4-1 1-1h6c.6 0 1 .4 1 1s-.4 1-1 1zm-2 3H7c-.6 0-1-.4-1-1s.4-1 1-1h4c.6 0 1 .4 1 1s-.4 1-1 1zm5-6c-.3 0-.5-.1-.7-.3-.4-.4-.4-1 0-1.4L16.6 4l-1.3-1.3c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0l2 2c.4.4.4 1 0 1.4l-2 2c-.2.2-.4.3-.7.3z">
                </path>
                <path
                    d="M3 10c-.6 0-1-.4-1-1V8c0-2.8 2.2-5 5-5h10c.6 0 1 .4 1 1s-.4 1-1 1H7C5.3 5 4 6.3 4 8v1c0 .6-.4 1-1 1zm1 9c-.3 0-.5-.1-.7-.3l-2-2c-.4-.4-.4-1 0-1.4l2-2c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L3.4 16l1.3 1.3c.4.4.4 1 0 1.4-.2.2-.4.3-.7.3z">
                </path>
                <path
                    d="M13 17H3c-.6 0-1-.4-1-1s.4-1 1-1h10c1.7 0 3-1.3 3-3v-1c0-.6.4-1 1-1s1 .4 1 1v1c0 2.8-2.2 5-5 5z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="transfer" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M15.796 5l-2.049-2.342a1 1 0 011.506-1.317l3.5 4a1 1 0 010 1.317l-3.5 4a1 1 0 01-1.506-1.317L15.797 7H6a1 1 0 110-2h9.796zM4.204 13l2.049-2.341A1 1 0 004.747 9.34l-3.5 4a1 1 0 000 1.318l3.5 4a1 1 0 001.506-1.318L4.203 15H14a1 1 0 100-2H4.204zM4 6a1 1 0 11-2 0 1 1 0 012 0zm14 8a1 1 0 11-2 0 1 1 0 012 0z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="twitter" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16.9 4.763c.75-.45 1.35-1.2 1.65-2.026-.75.45-1.5.75-2.325.9-.75-.75-1.725-1.2-2.775-1.2a3.681 3.681 0 0 0-3.675 3.675c0 .3 0 .6.075.825-3.075-.15-5.775-1.575-7.575-3.825-.375.526-.525 1.201-.525 1.875 0 1.276.675 2.4 1.65 3.075-.6-.075-1.2-.224-1.65-.45v.075c0 1.8 1.275 3.3 2.925 3.6-.3.075-.6.15-.975.15-.225 0-.45 0-.675-.074.45 1.5 1.8 2.55 3.45 2.55-1.275.974-2.85 1.575-4.575 1.575-.3 0-.6 0-.9-.075 1.65 1.05 3.6 1.65 5.625 1.65 6.825 0 10.5-5.625 10.5-10.5v-.45c.75-.526 1.35-1.2 1.875-1.95-.675.3-1.35.525-2.1.6z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="unavailable" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M10 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="undo" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M4.204 10l2.049 2.341a1 1 0 1 1-1.506 1.318l-3.5-4a1 1 0 0 1 0-1.318l3.5-4A1 1 0 1 1 6.253 5.66L4.203 8H14.52C17.018 8 19 10.239 19 13v2c0 .488-.523 1-1 1s-1-.512-1-1v-1.961c0-1.83-.985-3.039-2.48-3.039H4.204z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="upload" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18.792 10.1c-.59-1.983-2.338-3.343-4.327-3.342h-.326c-.853-2.546-3.01-4.393-5.596-4.71-2.798-.343-5.497 1.18-6.786 3.812-1.28 2.612-.914 5.788.925 7.999A.812.812 0 103.93 12.82c-1.428-1.717-1.715-4.207-.716-6.247.99-2.02 3.031-3.172 5.132-2.915 2.106.258 3.858 1.883 4.393 4.101a.812.812 0 00.79.622h.937c1.256-.002 2.381.874 2.77 2.182.395 1.323-.062 2.764-1.114 3.55a.812.812 0 00.972 1.3c1.603-1.199 2.284-3.346 1.698-5.314z">
                </path>
                <path
                    d="M9 18.123c0 .484.448.877 1 .877s1-.393 1-.877v-5.709l1.293 1.293a1 1 0 001.414-1.414l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 101.414 1.414L9 12.414v5.709z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="user" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M10 11c3.924 0 6.925 2.25 8.91 6.584A1 1 0 0 1 18 19H2a1 1 0 0 1-.91-1.416C3.076 13.25 6.077 11 10 11zm6.354 6c-1.604-2.702-3.702-4-6.354-4s-4.75 1.298-6.354 4h12.708zM10 10c-2.384 0-4.5-2.116-4.5-4.5S7.616 1 10 1s4.5 2.116 4.5 4.5S12.384 10 10 10zm0-2c1.279 0 2.5-1.221 2.5-2.5S11.279 3 10 3 7.5 4.221 7.5 5.5 8.721 8 10 8z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="user-add" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16 8a1 1 0 1 0-2 0v1h-1a1 1 0 1 0 0 2h1v1a1 1 0 1 0 2 0v-1h1a1 1 0 1 0 0-2h-1V8zM5 6.521C5 4.591 6.546 3 8.484 3c1.939 0 3.485 1.59 3.485 3.521 0 1.93-1.546 3.521-3.485 3.521C6.546 10.042 5 8.452 5 6.521zM8.484 5C7.678 5 7 5.667 7 6.521c0 .854.678 1.521 1.484 1.521.807 0 1.485-.667 1.485-1.521C9.969 5.667 9.29 5 8.484 5zM3.983 17.182v.002-.002zM4.368 16c.13-.302.296-.632.506-.96C5.554 13.98 6.651 13 8.5 13c1.85 0 2.946.98 3.626 2.04.21.328.376.658.506.96H4.368zM14 17c.983-.18.983-.181.983-.182v-.003l-.002-.007-.003-.017a3.755 3.755 0 0 0-.056-.248 8.861 8.861 0 0 0-1.113-2.583C12.884 12.52 11.231 11 8.5 11c-2.73 0-4.384 1.52-5.31 2.96a8.855 8.855 0 0 0-1.168 2.83l-.004.018v.007l-.001.002v.001L3 17l-.983-.18A1 1 0 0 0 3 18h11a1 1 0 0 0 .983-1.18L14 17z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="user-remove" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12 10a1 1 0 0 1 1-1h4a1 1 0 1 1 0 2h-4a1 1 0 0 1-1-1zM5 6.521C5 4.591 6.546 3 8.484 3c1.939 0 3.485 1.59 3.485 3.521 0 1.93-1.546 3.521-3.485 3.521C6.546 10.042 5 8.452 5 6.521zM8.484 5C7.678 5 7 5.667 7 6.521c0 .854.678 1.521 1.484 1.521.807 0 1.485-.667 1.485-1.521C9.969 5.667 9.29 5 8.484 5zM3.983 17.182v.002-.002zM4.368 16c.13-.302.296-.632.506-.96C5.554 13.98 6.651 13 8.5 13c1.85 0 2.946.98 3.626 2.04.21.328.376.658.506.96H4.368zM14 17c.983-.18.983-.181.983-.182v-.003l-.002-.007-.003-.017a3.755 3.755 0 0 0-.056-.248 8.861 8.861 0 0 0-1.113-2.583C12.884 12.52 11.231 11 8.5 11c-2.73 0-4.384 1.52-5.31 2.96a8.855 8.855 0 0 0-1.168 2.83l-.004.018v.007l-.001.002v.001L3 17l-.983-.18A1 1 0 0 0 3 18h11a1 1 0 0 0 .983-1.18L14 17z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="user-success" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M18.743 7.331a1 1 0 0 1-.074 1.412l-3.333 3a1 1 0 0 1-1.338 0l-1.667-1.5a1 1 0 0 1 1.338-1.486l.998.898 2.664-2.398a1 1 0 0 1 1.412.074zM5 6.521C5 4.591 6.546 3 8.484 3c1.939 0 3.485 1.59 3.485 3.521 0 1.93-1.546 3.521-3.485 3.521C6.546 10.042 5 8.452 5 6.521zM8.484 5C7.678 5 7 5.667 7 6.521c0 .854.678 1.521 1.484 1.521.807 0 1.485-.667 1.485-1.521C9.969 5.667 9.29 5 8.484 5zM3.983 17.182v.002-.002zM4.368 16c.13-.302.296-.632.506-.96C5.554 13.98 6.651 13 8.5 13c1.85 0 2.946.98 3.626 2.04.21.328.376.658.506.96H4.368zM14 17c.983-.18.983-.181.983-.182v-.003l-.002-.007-.003-.017a3.755 3.755 0 0 0-.056-.248 8.861 8.861 0 0 0-1.113-2.583C12.884 12.52 11.231 11 8.5 11c-2.73 0-4.384 1.52-5.31 2.96a8.855 8.855 0 0 0-1.168 2.83l-.004.018v.007l-.001.002v.001L3 17l-.983-.18A1 1 0 0 0 3 18h11a1 1 0 0 0 .983-1.18L14 17z"
                    clip-rule="evenodd"></path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="users" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M12.742 1.905a1 1 0 0 0-.527 1.93c.777.211 1.363.939 1.363 1.816 0 .877-.585 1.604-1.361 1.817a1 1 0 1 0 .528 1.929 3.875 3.875 0 0 0 2.833-3.746 3.875 3.875 0 0 0-2.836-3.746zM7.565 1.87c-2.134 0-3.839 1.75-3.839 3.88s1.705 3.88 3.839 3.88c2.133 0 3.838-1.75 3.838-3.88S9.698 1.87 7.565 1.87zM5.726 5.75c0-1.052.837-1.88 1.839-1.88 1.001 0 1.838.828 1.838 1.88s-.837 1.88-1.838 1.88c-1.002 0-1.839-.828-1.839-1.88zm8.25 5.969a1 1 0 0 1 1.262-.64c1.807.593 2.776 2.212 3.282 3.453a10.754 10.754 0 0 1 .654 2.391l.007.046.001.014.001.004v.002c0 .001 0 .002-.992.121l.992-.12a1 1 0 0 1-.992 1.12h-1.845a1 1 0 1 1 0-2h.606a8.34 8.34 0 0 0-.285-.824c-.436-1.072-1.099-1.993-2.052-2.306a1 1 0 0 1-.639-1.261zM3.773 15.117a6.66 6.66 0 0 0-.53.993h8.607a6.66 6.66 0 0 0-.53-.993c-.703-1.078-1.843-2.087-3.774-2.087-1.93 0-3.07 1.01-3.773 2.087zm10.433 1.809l-.983.184.983-.183a1 1 0 0 1-.983 1.183H1.87a1 1 0 0 1-.983-1.183l.983.183-.983-.184v-.004l.002-.006.003-.018a3.913 3.913 0 0 1 .058-.252 8.928 8.928 0 0 1 1.147-2.623c.955-1.462 2.652-2.993 5.45-2.993 2.796 0 4.494 1.531 5.448 2.994a8.928 8.928 0 0 1 1.206 2.874l.003.018.001.006v.003h.001z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="video" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M3.223 4h7.554C12.005 4 13 5.03 13 6.3v7.4c0 1.27-.995 2.3-2.223 2.3H3.223C1.995 16 1 14.97 1 13.7V6.3C1 5.03 1.995 4 3.223 4zm.41 2C3.283 6 3 6.297 3 6.663v6.674c0 .366.284.663.633.663h6.734c.35 0 .633-.297.633-.663V6.663c0-.366-.284-.663-.633-.663H3.633zm8.809 5.687A.75.75 0 0 1 12 11V9a.75.75 0 0 1 .442-.687l5.521-2.461A.74.74 0 0 1 19 6.538v6.924a.74.74 0 0 1-1.037.686l-5.521-2.461zM17 12V8l-3 1.559v.882L17 12z">
                </path>
            </symbol>
            <symbol viewBox="0 0 20 20" id="wave" xmlns="http://www.w3.org/2000/svg">
                <title>Wave</title>
                <path
                    d="M2.404 14.668l.087.029c1.044.344 2.159-.208 2.478-1.227l1.18-3.965c.32-1.02-.273-2.135-1.317-2.48l-.087-.028c-1.043-.345-2.159.208-2.478 1.227l-1.18 3.965c-.32 1.019.273 2.135 1.317 2.48">
                </path>
                <path
                    d="M10.068 15.275c.245-.59.424-1.27.611-1.874.413-1.33.774-2.685 1.172-4.02l.497-1.683c.364-1.164-.191-2.398-1.235-2.742l-.087-.029c-1.041-.343-2.189.323-2.557 1.48l-2.228 7.621c-.306.98-1.03 1.694-1.872 1.97a2.406 2.406 0 0 1-1.526.007l-.087-.029a2.397 2.397 0 0 1-.201-.08c.46.681 1.388 1.407 2.473 1.773 1.207.406 2.595.226 3.635-.523.677-.487 1.094-1.122 1.405-1.871M15.833 15.269c-.088.256-1.442 3.88-5.759 2.36 0 0 .89-.288 1.183-1.34.141-.506 1.384-4.72 1.384-4.72h.003l2.385-8.238c.32-1.02 1.434-1.571 2.478-1.227l.087.029c1.044.344 1.637 1.46 1.318 2.48l-2.565 8.857s-.425 1.542-.514 1.799">
                </path>
            </symbol>
        </svg>
    </div> 
    <style>
    body div#qual_ol .qual_ol_ans_tick,
    body div#qual_ol .qual_x_select .qual_ol_ans_tick {
        left: -16px;
        top: 14px
    }

    body div#qual_ol .qual_ol_ans_item {
        padding-left: 60px
    }

    body div#qual_ol .qual_ol_ans_item.qual_x_select {
        display: flex;
        flex-wrap: wrap;
        min-height: 45px;
        align-items: center;
        padding-left: 45px
    }
    </style>
    <div id="Content" style="height:100%" bis_skin_checked="1">
        <div class="wv-frame wv-frame--app pg-launchpad zzzzzz " style="" bis_skin_checked="1">
            <div class="advisor-bar-container" bis_skin_checked="1"></div>
            <div class="wv-frame__global" bis_skin_checked="1"></div>
            <div class="wv-frame__wrapper" bis_skin_checked="1">
           <?php include 'sidebar.php';?>
                <div class="wv-frame__content" bis_skin_checked="1">
                <?php include 'header.php';?>
                    <div class="wv-frame__content__body" bis_skin_checked="1">
                        <div class="wv-frame__content__body__side wv-frame__content__body__side--left"
                            bis_skin_checked="1"></div>
                        <div class="wv-frame__content__body__main" bis_skin_checked="1">
                            <div class="wv-frame__content__body__main__wrapper" data-testid="frame-wrapper"
                                bis_skin_checked="1">
                                <div bis_skin_checked="1">
                                    <div class="wv-header--page" bis_skin_checked="1">
                                        <div class="wv-header__title" bis_skin_checked="1">
                                            <h1 class="wv-heading--title pBIdHJ83x0HAnaL8yRd5 fs-exclude">Customers</h1>
                                        </div>
                                        <div class="wv-header__actions" bis_skin_checked="1">
                                            <div class="wv-dropdown fs-exclude" bis_skin_checked="1"><button
                                                    class="wv-dropdown__toggle wv-button">Import from...<svg
                                                        class="wv-svg-icon" aria-labelledby="open-menu-title"
                                                        aria-hidden="false">
                                                        <title id="open-menu-title">open menu icon</title>
                                                        <use xlink:href="#open-menu"></use>
                                                    </svg></button></div><a href="add_customer.php"
                                                class="wv-button--primary fs-exclude">Add a customer</a>
                                        </div>
                                    </div>
                                    <div class="D9gVVGO37ZrbM4ynlmH5" bis_skin_checked="1"><span
                                            class="wv-prefixed-input wv-prefixed-input--medium"><span
                                                class="wv-prefixed-input__prefix"><svg class="wv-svg-icon"
                                                    aria-labelledby="search-title" aria-hidden="false">
                                                    <title id="search-title">search icon</title>
                                                    <use xlink:href="#search"></use>
                                                </svg></span><input class="wv-input fs-exclude"
                                                placeholder="Search by name" type="search" autocapitalize="default"
                                                autocorrect="ON" value=""></span><span
                                            data-testid="customerCounter"><span
                                                class="wv-counter fuKT0a3nd19f45riV8fK">1</span>
                                            <p class="wv-text wv-text--body fs-exclude wv-text--inline">customer found
                                            </p>
                                        </span></div>
                                    <table class="wv-table fhD9hnxxnO9cBGcoYOjZ">
                                        <thead class="wv-table__header">
                                            <tr class="wv-table__row">
                                                <th class="wv-table__cell fs-exclude" colspan="1"><span
                                                        class="wv-table__sort-trigger sort-asc">Name</span></th>
                                                <th class="wv-table__cell fs-exclude" colspan="1">Email</th>
                                                <th class="wv-table__cell fs-exclude" colspan="1">Phone</th>
                                                <th class="wv-table__cell fs-exclude" colspan="1"><span
                                                        class="wv-table__sort-trigger sort-desc TBbnIi4J6kMomjLywF9a">Saved
                                                        cards <svg class="wv-svg-icon wv-tooltip__trigger"
                                                            aria-labelledby="help-title" aria-hidden="true"
                                                            tabindex="0">
                                                            <use xlink:href="#help"></use>
                                                        </svg></span></th>
                                                <th class="wv-table__cell--amount lK4QetxgrTdnGITg_bHf fs-exclude"
                                                    colspan="1"><span class="BC_NqG9F71xLjTm1uXpE"><span
                                                            class="wv-table__sort-trigger sort-desc TBbnIi4J6kMomjLywF9a">Balance</span></span>
                                                    <p class="wv-text wv-text--hint fs-exclude wv-text--inline">|</p>
                                                    <span class="G7sGHeNkNJL_acddZzWx"><span
                                                            class="wv-table__sort-trigger sort-desc TBbnIi4J6kMomjLywF9a">Overdue</span></span>
                                                </th>
                                                <th class="wv-table__cell fs-exclude" colspan="1"></th>
                                            </tr>
                                        </thead>
                                        <tbody class="wv-table__body">
                                            <tr class="wv-table__row">
                                                <td class="wv-table__cell fs-exclude" colspan="1">
                                                    <div class="fs-exclude" bis_skin_checked="1">Lido Carrier<p
                                                            class="wv-text wv-text--hint fs-exclude wv-text--inline">
                                                            <br>Derman K
                                                        </p>
                                                    </div>
                                                </td>
                                                <td class="wv-table__cell fs-exclude fs-exclude" colspan="1">
                                                    Derman87@gmail.com</td>
                                                <td class="wv-table__cell fs-exclude fs-exclude" colspan="1">5128766778
                                                </td>
                                                <td class="wv-table__cell fs-exclude" colspan="1"></td>
                                                <td class="wv-table__cell--amount fs-exclude" colspan="1">
                                                    <div class="alkXy_Am0aF0DF55DUjL" bis_skin_checked="1">
                                                        <p
                                                            class="wv-text wv-text--body YfiAlOOv4eNtOPemtLgi fs-exclude wv-text--inline">
                                                            $4,698.19</p>
                                                        <p
                                                            class="wv-text wv-text--hint YfiAlOOv4eNtOPemtLgi fs-exclude wv-text--inline">
                                                        </p>
                                                        <p
                                                            class="wv-text wv-text--hint qHC2BGVpsGdKxEs5RcYC fs-exclude wv-text--inline">
                                                            $4,698.19 overdue</p>
                                                    </div>
                                                </td>
                                                <td class="wv-table__cell fs-exclude" colspan="1">
                                                    <div class="BmfV3aOmGAMMyy5H1WWN" bis_skin_checked="1">
                                                        <div class="wv-dropdown fs-exclude" bis_skin_checked="1"><button
                                                                class="wv-dropdown__toggle wv-button--small wv-button--secondary"><svg
                                                                    class="wv-svg-icon"
                                                                    aria-labelledby="open-menu-title"
                                                                    aria-hidden="false">
                                                                    <title id="open-menu-title">open menu icon</title>
                                                                    <use xlink:href="#open-menu"></use>
                                                                </svg></button></div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon84400310097" bis_skin_checked="1">
        <img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon895218471089" width="0"
            height="0" alt=""
            src="https://bat.bing.com/action/0?ti=25032508&amp;Ver=2&amp;mid=3c191c2b-3cbf-484b-ba52-40f6d88a050f&amp;sid=654d6ed0fe4811edb13dc185139484ca&amp;vid=654decb0fe4811ed92bea9ed60b05a1f&amp;vids=0&amp;msclkid=N&amp;uach=pv%3D10.0.0&amp;pi=918639831&amp;lg=en-US&amp;sw=1440&amp;sh=900&amp;sc=24&amp;tl=Wave&amp;p=https%3A%2F%2Fnext.waveapps.com%2F4ca14d42-ebb1-425c-8837-93261d4e42c6%2Flaunchpad%2Finvoicing&amp;r=&amp;evt=pageLoad&amp;sv=1&amp;rn=626066">
    </div><iframe src="about:blank" style="display: none;" data-gtm-yt-inspected-185="true"
        data-gtm-yt-inspected-33866_340="true"></iframe>
    <div id="WPPTrackingId" style="display: none;" bis_skin_checked="1">85464e81fb334c29e62c13490bf415e4</div><iframe
        data-product="web_widget" title="No content" role="presentation" tabindex="-1" allow="microphone *"
        aria-hidden="true" src="about:blank"
        style="width: 0px; height: 0px; border: 0px; position: absolute; top: -9999px;" data-gtm-yt-inspected-185="true"
        data-gtm-yt-inspected-33866_340="true"></iframe>
    <iframe id="tdz_ifrm" title="empty" name="" width="0px" height="0px" marginwidth="0" marginheight="0"
        frameborder="0" aria-disabled="true" aria-hidden="true" tabindex="-1"
        src="https://h.online-metrix.net/fp/HP?session_id=85464e81fb334c29e62c13490bf415e4&amp;org_id=hkekmym4&amp;nonce=6d3d1f2631d06b09&amp;mode=2&amp;hp=.co-operativebank.co.uk/CBIBSWeb/login.do.co-operativebank.co.uk/CBIBSWeb/start.do.de/portal/portal/x.entropay.com/basemenu/prot/x.facebook.comx.nationet.com/x.netbank.commbank.com.au/netbank/bankmainx.npbs.co.uk/netmastergoldbanking/x.nwolb.xlogin.aspx?refereridentx.rbsdigital.xAccountSummaryx.smile.co.uk/SmileWeb/login.do.smile.co.uk/SmileWeb/start.do.yandex.rux/CapitalOne_Consumer/x/easypay.by/x/sbank.ru/x53.com/servlet/efsonlinex://online.wellsfargo.com/x://secure.assist.ru/assistid/protected/main.doxabbeynational.co.uk/EBAN_ENS/BtoChannelDriverxalliance-leicesterxaltergold.com/login.phpxamericanexpress.com/myca/intl/acctsumm/emea/accountSummaryxbancaintesa.it/xbankcardservices.co.ukxbankofamerica.com/xbanquepopulaire.fr/xbnpparibas.net/xcahoot.comxcapitaloneonline.co.uk/CapitalOne_Consumer/Transactionsxcbonline.co.uk/ralu/reglm-web/setupSecurityQuestionPagexcibc.comxPreSignOnxcibc.comxSignOnxcitibank.ru/xclient.uralsibbank.ruxco-operativebank.co.uk/CBIBSWeb/loginSpixcommerceonlinebanking.comxcoventrybuildingsociety.co.ukxdeutsche-bank.dexdiscovercard.com/cardmembersvcs/strongauth/app/sa_mainxebanking.bawag.comxebc_ebc1961xegg.com/customer/movemoneyxegg.com/customer/yourmoneyxfacebook.com/xhalifax-online.co.ukxMyAccountsxhalifax-online.co.uk/x/Mhalifax-online.co.uk/personalxhsbc.co.uk/1/2/personal/internet-banking/xhsbc.comxhttps://banking.postbank.de/app/finanzstatus.init.do;jsessionidxib.fineco.it/FinecoWeb/BonificiServletxib.fineco.it/FinecoWeb/jsp/Main/HBFineco.jspxib.fineco.it/FinecoWeb/jsp/Main/Principale.jspxibank.alfabank.ruxin-biz.it/xipko.plxlibertyreserve.com/x/historylibertyreserve.com/x/loginwww.libertyreserve.com/x/Core.jswww.libertyreserve.com/x/transfer.libertyreserve.com/x/commonscript.jslloydstsb.co.uk/personal/a/account_overview/xmbna.co.ukxmenyala.ruxmoney.yandex.ruxmoneybookers.com/app/login.plxmoneymail.ruxmy.ebay.co.uk/ws/eBayISAPI.dll?MyEbayxmy.ebay.com/ws/eBayISAPI.dll?MyEbayxmy.ebay.fr/ws/eBayISAPI.dll?MyEbayxmybusinessbank.co.ukxnationet.com/AppServices/SignOn/SignOnProcess/RcaSignOnxnpbs.co.ukxnwolb.com/AccountSummaryxnwolb.com/Statementsxnwolb.com/TransfersLandingPagexoltx.fidelity.com/x/x/ofsummary/summaryxonline.lloydstsb.co.ukxonlinebanking.mandtbank.com/summary/AccountSummaryxpassport.yandex.ruxpaypal.com/x/cgi-bin/webscr?cmd=_accountxpaypal.com/x/cgi-bin/webscr?cmd=_login-done&amp;login_access=xpaypal.com/us/cgi-bin/webscr?cmd=_login-done&amp;login_access=xposte.it/xpsk.co.at/xsecure.lloydstsb.co.uk/personal/a/account_overviewxsmile.co.uk/SmileWeb/passcodexusaa.com/xusbank.com/internetBanking/RequestRouter?requestCmdId=Gxwachovia.comxybonline.co.uk/ralu/reglm-web/setupSecurityQuestionPagex.amazon.fr/xhistory/orders/view.htmlx.banquepopulaire.frxShowPortal.dox.bnpparibasfortis.bexHome_Logon.aspx.cdiscount.com/Account/Home.aspxx.cmb.frxaccueil.jspx.credit-agricole.frxentreeBam?sessionSAGx.labanquepostale.fr/xreleveCPP-releve_ccp.eax.secure.bnpparibas.net/NSFR?Actionx.secure.lcl.frxAccueilxcredem.it/OneToOne/ebank/functionsxmijn.ing.nl/xonline.ybs.co.ukxwww.discover.com/xorder.cdiscount.comxCustomer.aspxxsealinfo.verisign.com/splash?form_filexvos-comptes.credit-du-nord.fr/CDC_TableauDeBord_0.asp?xvoscomptesenligne.labanquepostale.frxwww.x.caisse-epargne.fr/Portail.aspxxwww.exabanque.netxonglet.phpxdeutsche-bank.de/xnorisbank.de/xpostbank.de/xtargobank.de/x.x.de/portal/x.bankofamerica.com/x/commonscript.js.bmo.com/OLB?id=x.bmo.com/RMC?id=x.chase.com/x.aspxx.chase.com/js/Reporting.jsx.koodomobile.com/account/selfserve/x/xaccountId=x.payment.ru/x.scotiabank.com/portal/index.jsp?xbancopopular.es/empresasxcreval.it/login2007/loginSiciliano.aspxfirst-direct.com/xipko.plxmybusinessbank.co.ukxsanpaoloimi.com/xulsterbankanytimebanking.x/login.aspxx"
        style="display: none !important; z-index: -9999 !important; visibility: hidden !important;"
        bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:0,&quot;abs_y&quot;:0}"
        data-gtm-yt-inspected-185="true" data-gtm-yt-inspected-33866_340="true"></iframe>
    <div id="ada-entry" bis_skin_checked="1">
        <div bis_skin_checked="1"
            style="position: fixed; width: 635px; height: 785px; right: 0px; background: linear-gradient(315.92deg, rgba(0, 0, 0, 0.08) 0%, rgba(0, 0, 0, 0) 40.92%); bottom: 0px; pointer-events: none; z-index: 9999; transition: all 500ms linear 0s; opacity: 0;">
        </div>
    </div>
    <div class="wv-takeover session-warning" id="inactivity-modal-263464" role="dialog" aria-hidden="false"
        bis_skin_checked="1">
        <div class="wv-takeover__content" bis_skin_checked="1">
            <div class="wv-takeover__body" bis_skin_checked="1">
                <div class="illustration" bis_skin_checked="1">
                    <svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 380 320">
                        <defs>
                            <style>
                            .cls-1 {
                                fill-rule: evenodd;
                                fill: url(#linear-gradient);
                            }

                            .cls-2 {
                                fill: url(#linear-gradient-2);
                            }

                            .cls-3 {
                                fill: url(#linear-gradient-3);
                            }

                            .cls-4 {
                                fill: url(#linear-gradient-4);
                            }

                            .cls-5 {
                                fill: url(#linear-gradient-5);
                            }

                            .cls-6 {
                                fill: url(#linear-gradient-6);
                            }
                            </style>
                            <linearGradient id="linear-gradient" x1="190" y1="17.97" x2="190" y2="254.7"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0" stop-color="#2575db"></stop>
                                <stop offset="1" stop-color="#582994"></stop>
                            </linearGradient>
                            <linearGradient id="linear-gradient-2" x1="187.71" y1="41.62" x2="199.66" y2="297.6"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0.2" stop-color="#2575db"></stop>
                                <stop offset="1" stop-color="#582994"></stop>
                            </linearGradient>
                            <linearGradient id="linear-gradient-3" x1="142.09" y1="159.25" x2="235.37" y2="159.25"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0.03" stop-color="#9ae5fc"></stop>
                                <stop offset="0.99" stop-color="#e0f4ff"></stop>
                            </linearGradient>
                            <linearGradient id="linear-gradient-4" x1="188.72" y1="248.75" x2="188.72" y2="202.22"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0.03" stop-color="#2c87fc"></stop>
                                <stop offset="1" stop-color="#6ebfff"></stop>
                            </linearGradient>
                            <linearGradient id="linear-gradient-5" x1="188.72" y1="155.25" x2="188.72" y2="49.43"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0.41" stop-color="#2c87fc"></stop>
                                <stop offset="0.86" stop-color="#6ebfff"></stop>
                            </linearGradient>
                            <linearGradient id="linear-gradient-6" x1="188.71" y1="230.48" x2="188.71" y2="153.96"
                                gradientUnits="userSpaceOnUse">
                                <stop offset="0" stop-color="#e84855"></stop>
                                <stop offset="1" stop-color="#744af0"></stop>
                            </linearGradient>
                        </defs>
                        <title>spot_hourglass</title>
                        <path class="cls-1"
                            d="M329,160A139,139,0,0,1,66.57,224c-.39-.76-.77-1.52-1.15-2.28A139.15,139.15,0,0,1,80.3,74.62,139.93,139.93,0,0,1,96.61,57a139,139,0,0,1,232.18,95.33Q329,156.17,329,160Z">
                        </path>
                        <path class="cls-2"
                            d="M308.07,86.63,241,244.23,138.9,243,71.57,87.21A136.35,136.35,0,0,1,80.3,74.62,139.93,139.93,0,0,1,96.61,57,139,139,0,0,1,308.07,86.63Z">
                        </path>
                        <path class="cls-3"
                            d="M175,159.18S145,192,142.11,226.29a4.8,4.8,0,0,0,4.8,5.16h83.64a4.81,4.81,0,0,0,4.81-5.16c-2.87-34.31-32.91-67.11-32.91-67.11v-5.87s30-27.32,32.9-61.09a4.8,4.8,0,0,0-4.8-5.17H146.92a4.8,4.8,0,0,0-4.81,5.17C145,126,175,153.31,175,153.31Z">
                        </path>
                        <path class="cls-4"
                            d="M241.63,233.68v12.07H135.81V233.68a5.93,5.93,0,0,1,5.87-5.93h94A5.93,5.93,0,0,1,241.63,233.68Z">
                        </path>
                        <path class="cls-5"
                            d="M241.63,74.25V86.32a5.93,5.93,0,0,1-5.94,5.93h-94a5.93,5.93,0,0,1-5.87-5.93V74.25Z">
                        </path>
                        <path class="cls-6"
                            d="M222.17,224.24H155.26a4.8,4.8,0,0,1-4.69-5.84A99.24,99.24,0,0,1,159.78,194c2.64-4.86,12.55-6.75,22.4-9.65,3.4-1,4.9-5.22,4.9-8.64v-16.2c0-3.27-.69-6.19-3.46-8.35l-.07,0a17.52,17.52,0,0,1-1.64-1.23,2.11,2.11,0,0,1,.41-3.48,14.45,14.45,0,0,1,6.31-1.72,15.45,15.45,0,0,1,6.48,1.75,2.11,2.11,0,0,1,.45,3.49c-.33.27-.65.53-1,.76s-.48.33-.72.49c-2.93,2.17-3.72,5.11-3.72,8.41v16c0,3.48,1.53,7.5,5.28,8.91,9.38,2.84,20.57,5.72,22.63,10.22a98.42,98.42,0,0,1,8.81,23.6A4.8,4.8,0,0,1,222.17,224.24Z">
                        </path>
                    </svg>
                </div>
                <div class="wv-heading--title" bis_skin_checked="1">Looks like you’ve been away for a while</div>
                <div class="wv-text" bis_skin_checked="1">
                    As a security precaution, you will be signed out in
                    <strong class="countdown"></strong><br>
                    Remember to save anything you're working on.
                </div>
            </div>
            <div class="wv-takeover__actions" bis_skin_checked="1">
                <button class="wv-button--secondary modal-signout">Sign Out</button>
                <button class="wv-button--primary back">Back to Wave</button>
            </div>
        </div>
    </div>



</html>